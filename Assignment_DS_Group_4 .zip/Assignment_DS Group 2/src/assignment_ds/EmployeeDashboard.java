/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment_ds;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Angelta
 */
public class EmployeeDashboard extends javax.swing.JFrame {
   private int employeeID;
   private String employeeName; 
 
    
    /**
     * Creates new form EmployeeDashboard
     */
     public EmployeeDashboard(int employeeID) {
        this.employeeID = employeeID;
        setTitle("Employee Dashboard");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
panel.setLayout(new GridLayout(7, 1, 10, 10)); // Increase row count for welcome message




       

        
        JButton viewDetailsButton = new JButton("View Employee Details");
        JButton updateProfileButton = new JButton("Update Profile & Family Details");
        JButton applyLeaveButton = new JButton("Apply for Leave");
        JButton checkLeaveButton = new JButton("Check Leave Status");
        JButton editLeaveButton = new JButton("Edit Leave Details");
        JButton logoutButton = new JButton("Logout");

        viewDetailsButton.addActionListener(e -> viewEmployeeDetails());
        updateProfileButton.addActionListener(e -> updateProfile());
        applyLeaveButton.addActionListener(e -> applyForLeave());
        checkLeaveButton.addActionListener(e -> checkLeaveStatus());
        editLeaveButton.addActionListener(e -> editLeaveDetails());
        logoutButton.addActionListener(e -> logout());

        
      
        panel.add(viewDetailsButton);
        panel.add(updateProfileButton);
        panel.add(applyLeaveButton);
        panel.add(checkLeaveButton);
        panel.add(editLeaveButton);
        panel.add(logoutButton);

        add(panel);
    }
private void viewEmployeeDetails() {
    try (Connection connection = database.getConnection()) {
        if (connection == null || !connection.isValid(2)) {
            JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String query = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, employeeID);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            // Format details properly with all required fields
            String details =
                    "**Employee Details**\n\n" +
                    "Employee ID: " + resultSet.getInt("EMPLOYEE_ID") + "\n" +
                    "Name: " + resultSet.getString("FIRST_NAME") + " " + resultSet.getString("LAST_NAME") + "\n" +
                    "IC: " + resultSet.getString("IC") + "\n" +
                    "Spouse Name: " + resultSet.getString("SPOUSE_NAME") + "\n" +
                    "Spouse Contact: " + resultSet.getString("SPOUSE_CONTACT") + "\n" +
                    "Spouse Email: " + resultSet.getString("SPOUSE_EMAIL") + "\n" +
                    "Emergency Contact Name: " + resultSet.getString("EMERGENCY_CONTACT_NAME") + "\n" +
                    "Emergency Contact Number: " + resultSet.getString("EMERGENCY_CONTACT_PHONE") + "\n" +
                    "Relationship: " + resultSet.getString("EMERGENCY_CONTACT_RELATIONSHIP") + "\n" +
                    "Leave Balance: " + resultSet.getInt("LEAVE_BALANCE") + "\n";

            // Use JTextArea to display formatted text
            JTextArea textArea = new JTextArea(details);
            textArea.setEditable(false);
            textArea.setFont(new Font("Arial", Font.BOLD, 14));
            textArea.setBackground(new Color(250, 250, 250)); // Light background for better readability
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setMargin(new Insets(10, 10, 10, 10));

            // Wrap in a JScrollPane for proper display
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 250));

            JOptionPane.showMessageDialog(this, scrollPane, "Employee Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No employee found with ID: " + employeeID, "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error retrieving details: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}



    private void updateProfile() {
        String[] fields = {"FIRST_NAME", "LAST_NAME", "SPOUSE_NAME", "SPOUSE_CONTACT", "SPOUSE_EMAIL", "EMERGENCY_CONTACT_NAME", "EMERGENCY_CONTACT_RELATIONSHIP", "EMERGENCY_CONTACT_PHONE"};
        String fieldToUpdate = (String) JOptionPane.showInputDialog(this, "Select field to update:", "Update Profile", JOptionPane.QUESTION_MESSAGE, null, fields, fields[0]);
        if (fieldToUpdate != null) {
            String newValue = JOptionPane.showInputDialog(this, "Enter new value:");
            if (newValue != null && !newValue.trim().isEmpty()) {
                try (Connection connection = database.getConnection()) {
                    String query = "UPDATE EMPLOYEE SET " + fieldToUpdate + " = ? WHERE EMPLOYEE_ID = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, newValue);
                    statement.setInt(2, employeeID);
                    statement.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Profile updated successfully!");
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(this, "Error updating profile: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

   private void applyForLeave() {
    String leaveType = JOptionPane.showInputDialog(this, "Enter Leave Type:");
    if (leaveType == null) return; // If user clicks Cancel, exit method

    String startDate = JOptionPane.showInputDialog(this, "Enter Start Date (YYYY-MM-DD):");
    if (startDate == null) return; // Exit if Cancel is clicked

    String endDate = JOptionPane.showInputDialog(this, "Enter End Date (YYYY-MM-DD):");
    if (endDate == null) return; // Exit if Cancel is clicked

    // Ensure no empty values are saved
    if (leaveType.trim().isEmpty() || startDate.trim().isEmpty() || endDate.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "All fields must be filled!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try (Connection connection = database.getConnection()) {
        String query = "INSERT INTO LEAVES (EMPLOYEE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS) VALUES (?, ?, ?, ?, 'Pending')";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, employeeID);
        statement.setString(2, leaveType);
        statement.setString(3, startDate);
        statement.setString(4, endDate);

        int rowsInserted = statement.executeUpdate();
        if (rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Leave Application Submitted Successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to apply for leave.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error applying for leave: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}

    private void checkLeaveStatus() {
        try (Connection connection = database.getConnection()) {
            String query = "SELECT LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES WHERE EMPLOYEE_ID = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, employeeID);
            ResultSet resultSet = statement.executeQuery();

            StringBuilder status = new StringBuilder("Leave Status:\n");
            while (resultSet.next()) {
                status.append("Type: ").append(resultSet.getString("LEAVE_TYPE"))
                        .append(" | Start: ").append(resultSet.getString("START_DATE"))
                        .append(" | End: ").append(resultSet.getString("END_DATE"))
                        .append(" | Status: ").append(resultSet.getString("STATUS"))
                        .append("\n");
            }
            JOptionPane.showMessageDialog(this, status.toString(), "Leave Status", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error checking leave status: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

  private void editLeaveDetails() {
    try (Connection connection = database.getConnection()) {
        if (connection == null || !connection.isValid(2)) {
            JOptionPane.showMessageDialog(this, "Database connection failed.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Fetch all leave requests for the employee
        String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE FROM LEAVES WHERE EMPLOYEE_ID = ? AND STATUS = 'Pending'";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, employeeID);
        ResultSet resultSet = statement.executeQuery();

        // Create a dropdown list for Leave IDs
        java.util.List<String> leaveOptions = new ArrayList<>();
        while (resultSet.next()) {
            int leaveID = resultSet.getInt("LEAVE_ID");
            String leaveType = resultSet.getString("LEAVE_TYPE");
            String startDate = resultSet.getString("START_DATE");
            String endDate = resultSet.getString("END_DATE");
            leaveOptions.add(leaveID + " - " + leaveType + " (" + startDate + " to " + endDate + ")");
        }

        // If no leave requests exist, show a message and return
        if (leaveOptions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No pending leave requests found.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Show dropdown to select leave request
        String selectedLeave = (String) JOptionPane.showInputDialog(
                this,
                "Select the leave request to edit:",
                "Edit Leave",
                JOptionPane.QUESTION_MESSAGE,
                null,
                leaveOptions.toArray(),
                leaveOptions.get(0)
        );

        // If user clicks "Cancel" or closes the dialog, stop execution
        if (selectedLeave == null) {
            return;
        }

        // Extract LEAVE_ID from the selected item
        int leaveID = Integer.parseInt(selectedLeave.split(" - ")[0]);

        // Ask which field to edit
        String[] fields = {"LEAVE_TYPE", "START_DATE", "END_DATE"};
        String fieldToEdit = (String) JOptionPane.showInputDialog(
                this,
                "Select field to edit:",
                "Edit Leave",
                JOptionPane.QUESTION_MESSAGE,
                null,
                fields,
                fields[0]
        );

        if (fieldToEdit == null) return; // Stop if Cancel is clicked

        // Get new value
        String newValue = JOptionPane.showInputDialog(this, "Enter new value:");
        if (newValue == null || newValue.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No changes were made.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Update the leave record
        String updateQuery = "UPDATE LEAVES SET " + fieldToEdit + " = ? WHERE LEAVE_ID = ? AND EMPLOYEE_ID = ? AND STATUS = 'Pending'";
        PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
        updateStatement.setString(1, newValue);
        updateStatement.setInt(2, leaveID);
        updateStatement.setInt(3, employeeID);
        int rowsUpdated = updateStatement.executeUpdate();

        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Leave updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Update failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error updating leave: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}


 private void logout() {
    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to logout?",
        "Logout Confirmation",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm == JOptionPane.YES_OPTION) {
        JOptionPane.showMessageDialog(this, "You have successfully logged out. Redirecting to Login...");

        
        this.dispose();

       
        SwingUtilities.invokeLater(() -> {
            new EmployeeLogin().setVisible(true);
        });
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmployeeDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmployeeDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmployeeDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmployeeDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                int userID = 123; 
                new EmployeeDashboard(userID).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
