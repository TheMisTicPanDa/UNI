package assignment_ds;

import java.sql.Connection;
import java.sql.SQLException;
public class Main {
    public static void main(String[] args) {
      java.awt.EventQueue.invokeLater(() -> {
            int employeeID = ManageLogin.getLoggedInEmployeeID(); // Get employee ID after login
            if (employeeID > 0) {
                new EmployeeDashboard(employeeID).setVisible(true);
            } else {
                System.out.println("No valid employee ID. Redirecting to login.");
                new EmployeeLogin().setVisible(true);
            }
        });

        try {
            Connection connection = database.getConnection(); // Replace with actual DB method
            if (connection != null && connection.isValid(2)) {
                System.out.println("Database connection successful!");
            } else {
                System.out.println("Database connection failed!");
            }
        } catch (SQLException e) {
            System.out.println("Database connection error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
    
        
        
        /*Scanner scanner = new Scanner(System.in);

        System.out.println("Secure HR Management System");

        while (true) {
            System.out.println("\n1. Login");
            System.out.println("2. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            if (choice == 1) {
                System.out.print("Enter username: ");
                String username = scanner.nextLine();
                System.out.print("Enter password: ");
                String password = scanner.nextLine();

                if (ManageLogin.login(username, password)) {
                String userType = ManageLogin.getUserType(username);
                int employeeID = ManageLogin.getEmployeeIDByUsername(username); // Fetch employeeID

                if ("staff".equalsIgnoreCase(userType)) {
                    staffMenu(scanner);
                } else if ("employee".equalsIgnoreCase(userType)) {
                    Client client = new Client(employeeID); // Pass employeeID to Client
                    client.start(scanner);
                } else {
                    System.out.println("Unknown user type. Please contact admin.");
                }
                } else {
                System.out.println("Login failed. Invalid username or password.");
                }

            } else if (choice == 2) {
                System.out.println("Exiting system. Goodbye!");
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }

    private static void staffMenu(Scanner scanner) {
        Staff staff = new Staff();

        while (true) {
            System.out.println("\nStaff Terminal");
            System.out.println("1. Add Employee");
            System.out.println("2. Check Leaves");
            System.out.println("3. Generate Yearly Leave Report");
            System.out.println("4. View all employees");
            System.out.println("5. Edit employee details");
            System.out.println("6. Logout");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    staff.addEmployee();
                    break;
                case 2:
                    staff.updateLeaveStatus();
                    break;
                case 3:
                    staff.generateLeaveReport();
                    break;
                case 4:
                    staff.viewAllEmployees();
                    break;
                case 5:
                    staff.editEmployeeDetails();
                    break;
                case 6:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
} */
