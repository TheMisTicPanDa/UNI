 package assignment_ds;

/* import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.Month;
import java.util.Scanner;
import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Staff {

    private final Scanner scanner;

    public Staff() {
        this.scanner = new Scanner(System.in);
    }

    public void addEmployee() {
        System.out.println("Enter Employee Details:");

        // Employee details
        System.out.print("Employee ID: ");
        String id = scanner.nextLine();

        System.out.print("IC: ");
        String ic = scanner.nextLine();

        System.out.print("First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Spouse Name: ");
        String spouseName = scanner.nextLine();

        System.out.print("Spouse Contact: ");
        String spouseCont = scanner.nextLine();

        System.out.print("Spouse E-mail: ");
        String spouseMail = scanner.nextLine();

        System.out.print("Emergency Contact Name: ");
        String emerContName = scanner.nextLine();

        System.out.print("Emergency Contact Relationship: ");
        String emerContShip = scanner.nextLine();

        System.out.print("Emergency Contact Phone: ");
        String emerContPhone = scanner.nextLine();

        // Generate username and password
        String username = generateUsername(firstName, lastName);
        String password = generateRandomPassword();

        try (Connection connection = database.getConnection()) {
            System.out.println("Connected to the database.");

            // Insert employee details including username and password
            String employeeQuery = "INSERT INTO EMPLOYEE (EMPLOYEE_ID, IC, FIRST_NAME, LAST_NAME, SPOUSE_NAME, SPOUSE_CONTACT, SPOUSE_EMAIL, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_RELATIONSHIP, EMERGENCY_CONTACT_PHONE, USERNAME, PASSWORD) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement employeeStmt = connection.prepareStatement(employeeQuery);

            employeeStmt.setString(1, id);
            employeeStmt.setString(2, ic);
            employeeStmt.setString(3, firstName);
            employeeStmt.setString(4, lastName);
            employeeStmt.setString(5, spouseName);
            employeeStmt.setString(6, spouseCont);
            employeeStmt.setString(7, spouseMail);
            employeeStmt.setString(8, emerContName);
            employeeStmt.setString(9, emerContShip);
            employeeStmt.setString(10, emerContPhone);
            employeeStmt.setString(11, username);
            employeeStmt.setString(12, password);

            int employeeRows = employeeStmt.executeUpdate();
            if (employeeRows > 0) {
                System.out.println("Employee details added successfully!");

                // Insert credentials into USER table
                String userQuery = "INSERT INTO \"USERS\" (USERNAME, PASSWORD, EMPLOYEE_ID) VALUES (?, ?, ?)";
                PreparedStatement userStmt = connection.prepareStatement(userQuery);

                userStmt.setString(1, username);
                userStmt.setString(2, password);
                userStmt.setInt(3, Integer.parseInt(id)); // Convert employee ID from String to int

                int userRows = userStmt.executeUpdate();
                if (userRows > 0) {
                    System.out.println("User credentials created successfully!");
                    System.out.println("Username: " + username);
                    System.out.println("Temporary Password: " + password);

                    // Now register the user in the 'users.ser' file
                    ManageLogin.register(username, password, "employee", Integer.parseInt(id)); // Pass id as int
                } else {
                    System.out.println("Failed to create user credentials.");
                }
            } else {
                System.out.println("Failed to add employee details.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while adding employee to the database.");
        }
    }

    // Generate a unique username based on the first and last name
    private String generateUsername(String firstName, String lastName) {
        return firstName.toLowerCase() + "." + lastName.toLowerCase();
    }

    // Generate a random temporary password
    private String generateRandomPassword() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$!";
        StringBuilder password = new StringBuilder();
        int length = 8; // Password length

        for (int i = 0; i < length; i++) {
            int randomIndex = (int) (Math.random() * chars.length());
            password.append(chars.charAt(randomIndex));
        }
        return password.toString();
    }

//    public void updateLeaveStatus() {
//        System.out.print("Enter Employee ID to check and update leave status: ");
//        String employeeID = scanner.nextLine();
//
//        StringBuilder leaveDetails = new StringBuilder();
//        try (Connection connection = database.getConnection()) {
//            if (connection == null) {
//                System.out.println("Database connection error.");
//                return;
//            }
//
//            String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES WHERE EMPLOYEE_ID = ?";
//            try (PreparedStatement statement = connection.prepareStatement(query)) {
//                statement.setString(1, employeeID);
//                ResultSet resultSet = statement.executeQuery();
//
//                if (!resultSet.next()) {
//                    System.out.println("No leave records found for Employee ID: " + employeeID);
//                    return;
//                }
//
//                System.out.println("Leave Status for Employee ID: " + employeeID);
//                do {
//                    int leaveId = resultSet.getInt("LEAVE_ID");
//                    String leaveType = resultSet.getString("LEAVE_TYPE");
//                    String startDate = resultSet.getString("START_DATE");
//                    String endDate = resultSet.getString("END_DATE");
//                    String status = resultSet.getString("STATUS");
//
//                    leaveDetails.append("Leave ID: ").append(leaveId)
//                                .append(", Leave Type: ").append(leaveType)
//                                .append(", Start Date: ").append(startDate)
//                                .append(", End Date: ").append(endDate)
//                                .append(", Status: ").append(status)
//                                .append("\n");
//                } while (resultSet.next());
//
//                System.out.println(leaveDetails);
//
//                System.out.print("Enter Leave ID to update status (only Pending leave requests can be updated): ");
//                int leaveIdToUpdate = scanner.nextInt();
//                scanner.nextLine();
//
//                String checkStatusQuery = "SELECT STATUS, START_DATE, END_DATE FROM LEAVES WHERE LEAVE_ID = ? AND LOWER(STATUS) = LOWER('Pending')";
//                try (PreparedStatement checkStatusStmt = connection.prepareStatement(checkStatusQuery)) {
//                    checkStatusStmt.setInt(1, leaveIdToUpdate);
//                    ResultSet checkStatusResult = checkStatusStmt.executeQuery();
//
//                    if (!checkStatusResult.next()) {
//                        System.out.println("No Pending leave found for the given Leave ID or the Leave ID does not exist.");
//                        return;
//                    }
//
//                    System.out.println("Enter '1' to Accept or '2' to Decline the leave:");
//                    int choice = scanner.nextInt();
//                    scanner.nextLine();
//
//                    String newStatus = (choice == 1) ? "Accepted" : "Declined";
//
//                    if (newStatus.equalsIgnoreCase("Accepted")) {
//                        String startDate = checkStatusResult.getString("START_DATE");
//                        String endDate = checkStatusResult.getString("END_DATE");
//
//                        int leaveDays = calculateLeaveDays(startDate, endDate);
//
//                        if (!hasSufficientLeaveBalance(employeeID, leaveDays)) {
//                            System.out.println("Insufficient leave balance. Leave request cannot be approved.");
//                            return;
//                        }
//
//                        updateLeaveStatusInDatabase(leaveIdToUpdate, newStatus);
//                        updateLeaveBalance(employeeID, leaveDays);
//                    } else {
//                        updateLeaveStatusInDatabase(leaveIdToUpdate, newStatus);
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            System.out.println("Error occurred while updating leave status.");
//        }
//    }
    public void updateLeaveStatus() {
        System.out.print("Enter Employee ID to check leave status: ");
        String employeeID = scanner.nextLine();

        System.out.println("Filter by status: (Pending, Accepted, Declined, All)");
        System.out.print("Enter status filter (or type 'All' to view all requests): ");
        String statusFilter = scanner.nextLine().trim();

        StringBuilder leaveDetails = new StringBuilder();
        try (Connection connection = database.getConnection()) {
            if (connection == null) {
                System.out.println("Database connection error.");
                return;
            }

            // Modify query based on filter
            String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES WHERE EMPLOYEE_ID = ?";
            if (!statusFilter.equalsIgnoreCase("All")) {
                query += " AND LOWER(STATUS) = LOWER(?)";
            }

            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, employeeID);
                if (!statusFilter.equalsIgnoreCase("All")) {
                    statement.setString(2, statusFilter);
                }
                ResultSet resultSet = statement.executeQuery();

                if (!resultSet.next()) {
                    System.out.println("No leave records found for Employee ID: " + employeeID + " with status: " + statusFilter);
                    return;
                }

                System.out.println("Leave Requests for Employee ID: " + employeeID);
                do {
                    int leaveId = resultSet.getInt("LEAVE_ID");
                    String leaveType = resultSet.getString("LEAVE_TYPE");
                    String startDate = resultSet.getString("START_DATE");
                    String endDate = resultSet.getString("END_DATE");
                    String status = resultSet.getString("STATUS");

                    leaveDetails.append("Leave ID: ").append(leaveId)
                            .append(", Leave Type: ").append(leaveType)
                            .append(", Start Date: ").append(startDate)
                            .append(", End Date: ").append(endDate)
                            .append(", Status: ").append(status)
                            .append("\n");
                } while (resultSet.next());

                System.out.println(leaveDetails);

                // Only allow updating pending leave requests
                if (!statusFilter.equalsIgnoreCase("Pending") && !statusFilter.equalsIgnoreCase("All")) {
                    System.out.println("You can only update 'Pending' leave requests.");
                    return;
                }

                // Loop until a valid pending leave ID is entered
                while (true) {
                    System.out.print("Enter Leave ID to update status (only 'Pending' leave requests can be updated) or type 'Q' to quit: ");
                    String input = scanner.nextLine().trim();

                    if (input.equalsIgnoreCase("Q")) {
                        System.out.println("Exiting leave update process.");
                        return;
                    }

                    int leaveIdToUpdate;
                    try {
                        leaveIdToUpdate = Integer.parseInt(input);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a valid numeric Leave ID.");
                        continue;
                    }

                    String checkStatusQuery = "SELECT STATUS, START_DATE, END_DATE FROM LEAVES WHERE LEAVE_ID = ? AND LOWER(STATUS) = 'pending'";
                    try (PreparedStatement checkStatusStmt = connection.prepareStatement(checkStatusQuery)) {
                        checkStatusStmt.setInt(1, leaveIdToUpdate);
                        ResultSet checkStatusResult = checkStatusStmt.executeQuery();

                        if (!checkStatusResult.next()) {
                            System.out.println("No Pending leave found for the given Leave ID. Please try again or enter 'Q' to quit.");
                            continue;
                        }

                        System.out.println("Enter '1' to Accept or '2' to Decline the leave:");
                        int choice;
                        try {
                            choice = Integer.parseInt(scanner.nextLine().trim());
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid input. Please enter '1' to Accept or '2' to Decline.");
                            continue;
                        }

                        if (choice != 1 && choice != 2) {
                            System.out.println("Invalid choice. Please enter '1' to Accept or '2' to Decline.");
                            continue;
                        }

                        String newStatus = (choice == 1) ? "Accepted" : "Declined";

                        if (newStatus.equalsIgnoreCase("Accepted")) {
                            String startDate = checkStatusResult.getString("START_DATE");
                            String endDate = checkStatusResult.getString("END_DATE");

                            int leaveDays = calculateLeaveDays(startDate, endDate);

                            if (!hasSufficientLeaveBalance(employeeID, leaveDays)) {
                                System.out.println("Insufficient leave balance. Leave request cannot be approved.");
                                return;
                            }

                            updateLeaveStatusInDatabase(leaveIdToUpdate, newStatus);
                            updateLeaveBalance(employeeID, leaveDays);
                        } else {
                            updateLeaveStatusInDatabase(leaveIdToUpdate, newStatus);
                        }

                        System.out.println("Leave status updated successfully!");
                        break; // Exit loop after successful update
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while updating leave status.");
        }
    }

    private String calculateMonthlyDistribution(LocalDate start, LocalDate end) {
        Map<Integer, Integer> monthDays = new HashMap<>();
            while (!start.isAfter(end)) {
            int month = start.getMonthValue();
            monthDays.put(month, monthDays.getOrDefault(month, 0) + 1);
            start = start.plusDays(1);
        }

        return monthDays.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> String.format("%s: %d", Month.of(entry.getKey()), entry.getValue()))
                .collect(Collectors.joining(", "));
    }


        public void generateLeaveReport() {
        System.out.print("Enter Employee ID: ");
        int employeeID = scanner.nextInt();
        System.out.print("Enter Year: ");
        int year = scanner.nextInt();
        scanner.nextLine();

        try (Connection connection = database.getConnection()) {
            if (connection == null) {
                System.out.println("Database connection error.");
                return;
            }

            String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES " +
                           "WHERE EMPLOYEE_ID = ? AND CAST(SUBSTR(CAST(START_DATE AS CHAR(10)), 1, 4) AS INTEGER) = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, employeeID);
            statement.setInt(2, year);
            ResultSet resultSet = statement.executeQuery();

            if (!resultSet.next()) {
                System.out.println("No leave records found for Employee ID: " + employeeID + " in year " + year + ".");
                return;
            }

            System.out.println("\nLeave History Report for Employee ID: " + employeeID + " (Year: " + year + ")");
            System.out.println("--------------------------------------------------------------------------------------------------");
            System.out.println("| Leave ID | Type       | Start Date  | End Date    | Status     | Days  | Monthly Distribution |");
            System.out.println("--------------------------------------------------------------------------------------------------");

            int totalDays = 0, numberOfAcceptedLeaves = 0, declinedLeaves = 0, pendingLeaves = 0;
            Map<String, Integer> leaveTypeCount = new HashMap<>();

            do {
                int leaveId = resultSet.getInt("LEAVE_ID");
                String leaveType = resultSet.getString("LEAVE_TYPE");
                Date startDate = resultSet.getDate("START_DATE");
                Date endDate = resultSet.getDate("END_DATE");
                String status = resultSet.getString("STATUS");

                LocalDate startLocalDate = startDate.toLocalDate();
                LocalDate endLocalDate = endDate.toLocalDate();
                int daysBetween = (int) ChronoUnit.DAYS.between(startLocalDate, endLocalDate.plusDays(1)); 

                System.out.printf("| %-8d | %-10s | %-12s | %-12s | %-10s | %-4d | %-24s |\n",
                                  leaveId, leaveType, startDate, endDate, status, daysBetween, calculateMonthlyDistribution(startLocalDate, endLocalDate));

                if ("Accepted".equalsIgnoreCase(status)) {
                    totalDays += daysBetween;
                    numberOfAcceptedLeaves++;
                    leaveTypeCount.put(leaveType, leaveTypeCount.getOrDefault(leaveType, 0) + 1);
                } else if ("Declined".equalsIgnoreCase(status)) {
                    declinedLeaves++;
                } else if ("Pending".equalsIgnoreCase(status)) {
                    pendingLeaves++;
                }
            } while (resultSet.next());

            System.out.println("--------------------------------------------------------------------------------------------------");
            System.out.println("\nSummary Statistics:");
            System.out.println("- Total Leave Days: " + totalDays + " days");
            System.out.println("- Average Leave Duration: " + (numberOfAcceptedLeaves > 0 ? String.format("%.2f days per leave", (double) totalDays / numberOfAcceptedLeaves) : "N/A"));
            leaveTypeCount.forEach((type, count) -> System.out.println("- Leaves by Type: " + type + " (" + count + " record" + (count > 1 ? "s" : "") + ")"));
            System.out.println("- Number of Declined Leaves: " + declinedLeaves);
            System.out.println("- Number of Pending Leaves: " + pendingLeaves);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error generating leave report.");
        }
    }


    private boolean hasSufficientLeaveBalance(String employeeID, int leaveDays) {
        String checkBalanceQuery = "SELECT LEAVE_BALANCE FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
        try (Connection connection = database.getConnection();
                PreparedStatement statement = connection.prepareStatement(checkBalanceQuery)) {

            statement.setString(1, employeeID);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int leaveBalance = resultSet.getInt("LEAVE_BALANCE");
                return leaveBalance >= leaveDays;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while checking leave balance.");
        }
        return false;
    }

    private void updateLeaveStatusInDatabase(int leaveIdToUpdate, String newStatus) {
        String updateStatusQuery = "UPDATE LEAVES SET STATUS = ? WHERE LEAVE_ID = ?";
        try (Connection connection = database.getConnection();
                PreparedStatement updateStmt = connection.prepareStatement(updateStatusQuery)) {

            updateStmt.setString(1, newStatus);
            updateStmt.setInt(2, leaveIdToUpdate);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Leave status updated to " + newStatus);
            } else {
                System.out.println("Failed to update leave status.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while updating leave status.");
        }
    }

    private void updateLeaveBalance(String employeeID, int leaveDays) {
        String updateBalanceQuery = "UPDATE EMPLOYEE SET LEAVE_BALANCE = LEAVE_BALANCE - ? WHERE EMPLOYEE_ID = ?";
        try (Connection connection = database.getConnection();
                PreparedStatement updateStmt = connection.prepareStatement(updateBalanceQuery)) {

            updateStmt.setInt(1, leaveDays);
            updateStmt.setString(2, employeeID);

            int rowsAffected = updateStmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Leave balance updated successfully.");
            } else {
                System.out.println("Failed to update leave balance.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while updating leave balance.");
        }
    }

    private int calculateLeaveDays(String startDate, String endDate) {
        LocalDate start = LocalDate.parse(startDate);
        LocalDate end = LocalDate.parse(endDate);
        return (int) ChronoUnit.DAYS.between(start, end) + 1;
    }

    public void viewAllEmployees() {
        Scanner scanner = new Scanner(System.in);

        // Declare searchName outside of the if block to ensure it's accessible later
        String searchName = "";

        // Option to search by name
        System.out.print("Do you want to search for an employee by name? (yes/no): ");
        String searchChoice = scanner.nextLine();

        // If the user wants to search by name, prompt for the name
        String query;
        if (searchChoice.equalsIgnoreCase("yes")) {
            System.out.print("Enter the name to search: ");
            searchName = scanner.nextLine().trim(); // Assign the entered name to searchName

            // Modify the query to filter based on first or last name
            query = "SELECT EMPLOYEE_ID, IC, FIRST_NAME, LAST_NAME, SPOUSE_NAME, SPOUSE_CONTACT, SPOUSE_EMAIL, "
                    + "EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_RELATIONSHIP, EMERGENCY_CONTACT_PHONE, USERNAME "
                    + "FROM EMPLOYEE WHERE LOWER(FIRST_NAME) LIKE LOWER(?) OR LOWER(LAST_NAME) LIKE LOWER(?)";
        } else {
            // Default query to get all employees
            query = "SELECT EMPLOYEE_ID, IC, FIRST_NAME, LAST_NAME, SPOUSE_NAME, SPOUSE_CONTACT, SPOUSE_EMAIL, "
                    + "EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_RELATIONSHIP, EMERGENCY_CONTACT_PHONE, USERNAME FROM EMPLOYEE";
        }

        StringBuilder employeeDetails = new StringBuilder();

        try (Connection connection = database.getConnection()) {
            if (connection == null) {
                System.out.println("Database connection error.");
                return;
            }

            try (PreparedStatement statement = connection.prepareStatement(query)) {
                // If searching by name, set the parameter for the LIKE query
                if (searchChoice.equalsIgnoreCase("yes")) {
                    String namePattern = "%" + searchName + "%";  // Add wildcard for partial match
                    statement.setString(1, namePattern);
                    statement.setString(2, namePattern);
                }

                ResultSet resultSet = statement.executeQuery();

                if (!resultSet.next()) {
                    System.out.println("No employees found matching the criteria.");
                    return;
                }

                System.out.println("Employee Details:");
                do {
                    int employeeId = resultSet.getInt("EMPLOYEE_ID");
                    String ic = resultSet.getString("IC");
                    String firstName = resultSet.getString("FIRST_NAME");
                    String lastName = resultSet.getString("LAST_NAME");
                    String spouseName = resultSet.getString("SPOUSE_NAME");
                    String spouseContact = resultSet.getString("SPOUSE_CONTACT");
                    String spouseEmail = resultSet.getString("SPOUSE_EMAIL");
                    String emergencyContactName = resultSet.getString("EMERGENCY_CONTACT_NAME");
                    String emergencyContactRelationship = resultSet.getString("EMERGENCY_CONTACT_RELATIONSHIP");
                    String emergencyContactPhone = resultSet.getString("EMERGENCY_CONTACT_PHONE");
                    String username = resultSet.getString("USERNAME");

                    employeeDetails.append("Employee ID: ").append(employeeId)
                            .append(", IC: ").append(ic)
                            .append(", Name: ").append(firstName).append(" ").append(lastName)
                            .append(", Spouse: ").append(spouseName)
                            .append(", Spouse Contact: ").append(spouseContact)
                            .append(", Spouse Email: ").append(spouseEmail)
                            .append(", Emergency Contact: ").append(emergencyContactName)
                            .append(", Relationship: ").append(emergencyContactRelationship)
                            .append(", Emergency Phone: ").append(emergencyContactPhone)
                            .append(", Username: ").append(username)
                            .append("\n");
                } while (resultSet.next());

                System.out.println(employeeDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while retrieving employee details.");
        }
    }

    public void editEmployeeDetails() {
        Scanner scanner = new Scanner(System.in);

        // Prompt staff for employee ID to edit
        System.out.print("Enter the Employee ID to edit: ");
        int employeeId = scanner.nextInt();
        scanner.nextLine();  // Consume newline character

        // Retrieve current employee details before editing
        try (Connection connection = database.getConnection()) {
            if (connection == null) {
                System.out.println("Database connection error.");
                return;
            }

            String query = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, employeeId);
                ResultSet resultSet = statement.executeQuery();

                if (!resultSet.next()) {
                    System.out.println("Employee not found with ID: " + employeeId);
                    return;
                }

                // Retrieve the current details of the employee
                String firstName = resultSet.getString("FIRST_NAME");
                String lastName = resultSet.getString("LAST_NAME");
                String spouseName = resultSet.getString("SPOUSE_NAME");
                String spouseContact = resultSet.getString("SPOUSE_CONTACT");
                String spouseEmail = resultSet.getString("SPOUSE_EMAIL");
                String emergencyContactName = resultSet.getString("EMERGENCY_CONTACT_NAME");
                String emergencyContactRelationship = resultSet.getString("EMERGENCY_CONTACT_RELATIONSHIP");
                String emergencyContactPhone = resultSet.getString("EMERGENCY_CONTACT_PHONE");
                String username = resultSet.getString("USERNAME");

                // Display current details
                System.out.println("Current Employee Details:");
                System.out.println("1. First Name: " + firstName);
                System.out.println("2. Last Name: " + lastName);
                System.out.println("3. Spouse Name: " + spouseName);
                System.out.println("4. Spouse Contact: " + spouseContact);
                System.out.println("5. Spouse Email: " + spouseEmail);
                System.out.println("6. Emergency Contact Name: " + emergencyContactName);
                System.out.println("7. Emergency Contact Relationship: " + emergencyContactRelationship);
                System.out.println("8. Emergency Contact Phone: " + emergencyContactPhone);
                System.out.println("9. Username: " + username);

                // Prompt staff to select the field to edit
                System.out.print("\nEnter the number of the field you want to modify (1-9): ");
                int fieldChoice = scanner.nextInt();
                scanner.nextLine();  // Consume newline character

                // Prompt for new value based on the field chosen
                String newValue = "";
                switch (fieldChoice) {
                    case 1:
                        System.out.print("Enter new First Name (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = firstName;
                        }
                        updateEmployeeField(employeeId, "FIRST_NAME", newValue);
                        break;
                    case 2:
                        System.out.print("Enter new Last Name (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = lastName;
                        }
                        updateEmployeeField(employeeId, "LAST_NAME", newValue);
                        break;
                    case 3:
                        System.out.print("Enter new Spouse Name (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = spouseName;
                        }
                        updateEmployeeField(employeeId, "SPOUSE_NAME", newValue);
                        break;
                    case 4:
                        System.out.print("Enter new Spouse Contact (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = spouseContact;
                        }
                        updateEmployeeField(employeeId, "SPOUSE_CONTACT", newValue);
                        break;
                    case 5:
                        System.out.print("Enter new Spouse Email (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = spouseEmail;
                        }
                        updateEmployeeField(employeeId, "SPOUSE_EMAIL", newValue);
                        break;
                    case 6:
                        System.out.print("Enter new Emergency Contact Name (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = emergencyContactName;
                        }
                        updateEmployeeField(employeeId, "EMERGENCY_CONTACT_NAME", newValue);
                        break;
                    case 7:
                        System.out.print("Enter new Emergency Contact Relationship (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = emergencyContactRelationship;
                        }
                        updateEmployeeField(employeeId, "EMERGENCY_CONTACT_RELATIONSHIP", newValue);
                        break;
                    case 8:
                        System.out.print("Enter new Emergency Contact Phone (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = emergencyContactPhone;
                        }
                        updateEmployeeField(employeeId, "EMERGENCY_CONTACT_PHONE", newValue);
                        break;
                    case 9:
                        System.out.print("Enter new Username (or press Enter to keep current): ");
                        newValue = scanner.nextLine();
                        if (newValue.isEmpty()) {
                            newValue = username;
                        }
                        updateEmployeeField(employeeId, "USERNAME", newValue);
                        break;
                    default:
                        System.out.println("Invalid choice. Please select a number between 1 and 9.");
                        break;
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while editing employee details.");
        }
    }

    private void updateEmployeeField(int employeeId, String fieldName, String newValue) {
        try (Connection connection = database.getConnection()) {
            String updateQuery = "UPDATE EMPLOYEE SET " + fieldName + " = ? WHERE EMPLOYEE_ID = ?";
            try (PreparedStatement statement = connection.prepareStatement(updateQuery)) {
                statement.setString(1, newValue);
                statement.setInt(2, employeeId);
                int rowsAffected = statement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println(fieldName + " updated successfully.");
                } else {
                    System.out.println("Failed to update " + fieldName);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error occurred while updating the field.");
        }
    }

}
*/