package assignment_ds;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface Interface extends Remote {
    String applyForLeave(String employeeID, String leaveType, String startDate, String endDate) throws RemoteException;
    String checkLeaveStatus(String employeeID) throws RemoteException;
    String processRequest(int choice, String ID) throws RemoteException;
    boolean verifyEmployee(int employeeID, String firstName, String lastName) throws RemoteException;
    String updateSpecificField(int employeeID, String field, String newValue) throws RemoteException;
    String generateLeaveReport(int employeeID, int year) throws RemoteException;
    List<String> viewPendingLeaves(int employeeID) throws RemoteException;
    String modifyLeaveDetails(int employeeID, int leaveID, String fieldToModify, String newValue) throws RemoteException;
    String login(String username, String password) throws RemoteException;
    
    
}




