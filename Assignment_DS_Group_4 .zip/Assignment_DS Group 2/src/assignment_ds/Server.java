package assignment_ds;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.Month;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Server extends UnicastRemoteObject implements Interface {

    public Server() throws RemoteException {
        super();//SUPPEERRR IMPORTANT !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }
    
    @Override
public String login(String username, String password) throws RemoteException {
    try (Connection connection = database.getConnection()) {
        String query = "SELECT USER_ID, USERTYPE, PASSWORD FROM USERS WHERE USERNAME = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet rs = statement.executeQuery();

        if (rs.next()) {
            String storedPass = rs.getString("PASSWORD");
            if (storedPass.equals(password)) {
                int userID = rs.getInt("USER_ID");
                String userType = rs.getString("USERTYPE");
                return "SUCCESS," + userID + "," + userType;
            } else {
                return "Invalid credentials.";
            }
        } else {
            return "User not found.";
        }
    } catch (SQLException e) {
        return "Database error: " + e.getMessage();
    }
}


    @Override
    public String processRequest(int choice, String employeeID) throws RemoteException {
        switch (choice) {
            case 1:
                return getEmployeeDetails(employeeID);
            case 4:
                return "Exiting system. Goodbye!";
            default:
                return "Invalid choice. Please try again.";
        }
    }

    @Override
    public boolean verifyEmployee(int employeeID, String firstName, String lastName) throws RemoteException {
        String query = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = ? AND LOWER(FIRST_NAME) = LOWER(?) AND LOWER(LAST_NAME) = LOWER(?)";
        try (Connection connection = database.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, employeeID);
            statement.setString(2, firstName);
            statement.setString(3, lastName);
            ResultSet resultSet = statement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            System.err.println("Error verifying employee: " + e.getMessage());
            return false;
        }
    }

    @Override
    public String updateSpecificField(int employeeID, String field, String newValue) throws RemoteException {
        String query = "UPDATE EMPLOYEE SET " + field + " = ? WHERE EMPLOYEE_ID = ?";
        try (Connection connection = database.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, newValue);
            statement.setInt(2, employeeID);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0 ? "Field updated successfully." : "No changes were made.";
        } catch (SQLException e) {
            return "Error updating field: " + e.getMessage();
        }
    }

    private String getEmployeeDetails(String employeeID) {
        StringBuilder result = new StringBuilder();
        String query = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
        try (Connection connection = database.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, Integer.parseInt(employeeID));
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                result.append("Employee Details:\n");
                result.append("ID: ").append(resultSet.getInt("EMPLOYEE_ID")).append("\n");
                result.append("First Name: ").append(resultSet.getString("FIRST_NAME")).append("\n");
                result.append("Last Name: ").append(resultSet.getString("LAST_NAME")).append("\n");
                result.append("IC: ").append(resultSet.getString("IC")).append("\n");
                result.append("Spouse Name: ").append(resultSet.getString("SPOUSE_NAME") == null ? "N/A" : resultSet.getString("SPOUSE_NAME")).append("\n");
                result.append("Spouse Contact: ").append(resultSet.getString("SPOUSE_CONTACT") == null ? "N/A" : resultSet.getString("SPOUSE_CONTACT")).append("\n");
                result.append("Spouse Email: ").append(resultSet.getString("SPOUSE_EMAIL") == null ? "N/A" : resultSet.getString("SPOUSE_EMAIL")).append("\n");
                result.append("Emergency Contact Name: ").append(resultSet.getString("EMERGENCY_CONTACT_NAME")).append("\n");
                result.append("Emergency Contact Relationship: ").append(resultSet.getString("EMERGENCY_CONTACT_RELATIONSHIP")).append("\n");
                result.append("Emergency Contact Phone: ").append(resultSet.getString("EMERGENCY_CONTACT_PHONE")).append("\n");
                result.append("Leave Balance: ").append(resultSet.getString("LEAVE_BALANCE")).append("\n");
            } else {
                result.append("Employee not found.");
            }
        } catch (SQLException e) {
            result.append("Error occurred while fetching employee details: ").append(e.getMessage());
        }
        return result.toString();
    }

    @Override
    public String applyForLeave(String employeeID, String leaveType, String startDate, String endDate) throws RemoteException {
        try (Connection connection = database.getConnection()) {
            if (connection == null) {
                return "Database connection error.";
            }

            String query = "INSERT INTO LEAVES (EMPLOYEE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS) VALUES (?, ?, ?, ?, 'PENDING')";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, employeeID);
                statement.setString(2, leaveType);
                statement.setString(3, startDate);
                statement.setString(4, endDate);
                int rowsAffected = statement.executeUpdate();

                if (rowsAffected > 0) {
                    return "Leave application submitted successfully.";
                } else {
                    return "Failed to submit leave application.";
                }
            }
        } catch (SQLException e) {
            return "Error applying for leave: " + e.getMessage();
        }
    }

    @Override
    public String checkLeaveStatus(String employeeID) throws RemoteException {
        StringBuilder result = new StringBuilder();
        try (Connection connection = database.getConnection()) {
            if (connection == null) {
                return "Database connection error.";
            }

            String query = "SELECT LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES WHERE EMPLOYEE_ID = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, employeeID);
                ResultSet resultSet = statement.executeQuery();

                while (resultSet.next()) {
                    result.append("Leave Type: ").append(resultSet.getString("LEAVE_TYPE"))
                            .append(", Start Date: ").append(resultSet.getString("START_DATE"))
                            .append(", End Date: ").append(resultSet.getString("END_DATE"))
                            .append(", Status: ").append(resultSet.getString("STATUS"))
                            .append("\n");
                }
                return result.length() > 0 ? result.toString() : "No leave records found.";
            }
        } catch (SQLException e) {
            return "Error checking leave status: " + e.getMessage();
        }
    }

    public List<String> viewPendingLeaves(int employeeID) throws RemoteException {
        List<String> leaveDetails = new ArrayList<>();
        String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE FROM LEAVES WHERE EMPLOYEE_ID = ? AND STATUS = 'PENDING'";

        try (Connection connection = database.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, employeeID);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int leaveID = resultSet.getInt("LEAVE_ID");
                String leaveType = resultSet.getString("LEAVE_TYPE");
                String startDate = resultSet.getString("START_DATE");
                String endDate = resultSet.getString("END_DATE");
                leaveDetails.add("Leave ID: " + leaveID + ", Type: " + leaveType + ", Start: " + startDate + ", End: " + endDate);
            }
        } catch (SQLException e) {
            leaveDetails.add("Error fetching leave details: " + e.getMessage());
        }
        return leaveDetails;
    }

    @Override
public String modifyLeaveDetails(int employeeID, int leaveID, String fieldToModify, String newValue) throws RemoteException {
    String query = "";
    
    switch (fieldToModify) {
        case "LEAVE_TYPE":
            query = "UPDATE LEAVES SET LEAVE_TYPE = ? WHERE EMPLOYEE_ID = ? AND LEAVE_ID = ? AND STATUS = 'PENDING'";
            break;
        case "START_DATE":
            query = "UPDATE LEAVES SET START_DATE = ? WHERE EMPLOYEE_ID = ? AND LEAVE_ID = ? AND STATUS = 'PENDING'";
            break;
        case "END_DATE":
            query = "UPDATE LEAVES SET END_DATE = ? WHERE EMPLOYEE_ID = ? AND LEAVE_ID = ? AND STATUS = 'PENDING'";
            break;
        default:
            return "Invalid field to modify.";
    }

    try (Connection connection = database.getConnection();
         PreparedStatement statement = connection.prepareStatement(query)) {

        statement.setString(1, newValue);
        statement.setInt(2, employeeID);
        statement.setInt(3, leaveID);

        int rowsAffected = statement.executeUpdate();
        if (rowsAffected > 0) {
            return "Leave " + fieldToModify + " updated successfully.";
        } else {
            return "Leave not found or cannot be modified.";
        }
    } catch (SQLException e) {
        return "Error modifying leave details: " + e.getMessage();
    }
}

    private String calculateMonthlyDistribution(LocalDate start, LocalDate end) {
        Map<Integer, Integer> monthDays = new HashMap<>();
        while (!start.isAfter(end)) {
            int month = start.getMonthValue();
            monthDays.put(month, monthDays.getOrDefault(month, 0) + 1);
            start = start.plusDays(1);
        }

        return monthDays.entrySet().stream()
            .sorted(Map.Entry.comparingByKey())
            .map(entry -> String.format("%s: %d", Month.of(entry.getKey()), entry.getValue()))
            .collect(Collectors.joining(", "));
    }


                        @Override
     public String generateLeaveReport(int employeeID, int year) throws RemoteException {
         StringBuilder report = new StringBuilder();
         try (Connection connection = database.getConnection()) {
             if (connection == null) {
                 return "Database connection error.";
             }

             String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES " +
                            "WHERE EMPLOYEE_ID = ? AND CAST(SUBSTR(CAST(START_DATE AS CHAR(10)), 1, 4) AS INTEGER) = ?";
             PreparedStatement statement = connection.prepareStatement(query);
             statement.setInt(1, employeeID);
             statement.setInt(2, year);
             ResultSet resultSet = statement.executeQuery();

             if (!resultSet.next()) {
                 return "No leave records found for Employee ID: " + employeeID + " in year " + year + ".";
             }

             report.append("\nLeave History Report for Employee ID: ").append(employeeID).append(" (Year: ").append(year).append(")\n");
             report.append("------------------------------------------------------------------------------------------------\n");
             report.append("| Leave ID | Type       | Start Date  | End Date    | Status     | Days  | Monthly Distribution           |\n");
             report.append("------------------------------------------------------------------------------------------------\n");

             int totalDays = 0, numberOfAcceptedLeaves = 0, declinedLeaves = 0, pendingLeaves = 0;
             Map<String, Integer> leaveTypeCount = new HashMap<>();

             do {
                 int leaveId = resultSet.getInt("LEAVE_ID");
                 String leaveType = resultSet.getString("LEAVE_TYPE");
                 Date startDate = resultSet.getDate("START_DATE");
                 Date endDate = resultSet.getDate("END_DATE");
                 String status = resultSet.getString("STATUS");

                 LocalDate startLocalDate = startDate.toLocalDate();
                 LocalDate endLocalDate = endDate.toLocalDate();
                 int daysBetween = (int) ChronoUnit.DAYS.between(startLocalDate, endLocalDate.plusDays(1));

                 report.append(String.format("| %-8d | %-10s | %-12s | %-12s | %-10s | %-4d | %-24s |\n",
                                             leaveId, leaveType, startDate, endDate, status, daysBetween, calculateMonthlyDistribution(startLocalDate, endLocalDate)));

                 if ("Accepted".equalsIgnoreCase(status)) {
                     totalDays += daysBetween;
                     numberOfAcceptedLeaves++;
                     leaveTypeCount.put(leaveType, leaveTypeCount.getOrDefault(leaveType, 0) + 1);
                 } else if ("Declined".equalsIgnoreCase(status)) {
                     declinedLeaves++;
                 } else if ("Pending".equalsIgnoreCase(status)) {
                     pendingLeaves++;
                 }
             } while (resultSet.next());

             report.append("------------------------------------------------------------------------------------------------\n");
             report.append("\nSummary Statistics:\n");
             report.append("- Total Leave Days: ").append(totalDays).append(" days\n");
             report.append("- Average Leave Duration: ").append(numberOfAcceptedLeaves > 0 ? String.format("%.2f days per leave", (double) totalDays / numberOfAcceptedLeaves) : "N/A").append("\n");
             leaveTypeCount.forEach((type, count) -> report.append("- Leaves by Type: ").append(type).append(" (").append(count).append(" record").append(count > 1 ? "s" : "").append(")\n"));
             report.append("- Number of Declined Leaves: ").append(declinedLeaves).append("\n");
             report.append("- Number of Pending Leaves: ").append(pendingLeaves).append("\n");
         } catch (SQLException e) {
             return "Error generating leave report: " + e.getMessage();
         }
         return report.toString();
}


}