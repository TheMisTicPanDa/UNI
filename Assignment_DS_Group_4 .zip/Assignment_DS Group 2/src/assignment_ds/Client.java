package assignment_ds;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Scanner;

public class Client {

    private static int loggedInEmployeeID;

    public Client(int loggedInEmployeeID) {
        Client.loggedInEmployeeID = loggedInEmployeeID;
    }

    public void start(Scanner scanner) {
        Interface object = null;
        boolean connected = false;
        int attempts = 0;

        while (!connected && attempts < 5) {
            try {
                System.out.println("Attempting to connect... (Try " + (attempts + 1) + ")");
                object = (Interface) Naming.lookup("rmi://172.20.10.14:1044/HRMService");
                connected = true;
            } catch (Exception e) {
                System.out.println("Connection failed. Retrying...");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                attempts++;
            }
        }

        if (!connected) {
            System.out.println("Could not connect after multiple attempts. Exiting.");
            return;
        }

        System.out.println("Connected to HRM Service successfully!");
        System.out.println("Welcome, employee " + loggedInEmployeeID + "! Accessing the employee terminal...");
        clientMenu(object, scanner);
    }

    private static void clientMenu(Interface object, Scanner scanner) {
        while (true) {
            System.out.println("\nClient Menu:");
            System.out.println("1. View Employee Details");
            System.out.println("2. Update Profile and Family Details");
            System.out.println("3. Apply for Leave");
            System.out.println("4. Check Leave Status");
            System.out.println("5. Edit Leave Details");
            System.out.println("6. Log out");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            try {
                switch (choice) {
                    case 1:
                        viewEmployeeDetails(object);
                        break;
                    case 2:
                        updateEmployeeDetails(object, scanner);
                        break;
                    case 3:
                        applyForLeave(object, scanner);
                        break;
                    case 4:
                        checkLeaveStatus(object);
                        break;
                    case 5:
                        modifyLeaveApplication(object, scanner);
                        break;
                    case 6:
                        System.out.println("Logging out...");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (RemoteException e) {
                System.out.println("Error communicating with server: " + e.getMessage());
            }
        }
    }

    private static void viewEmployeeDetails(Interface object) throws RemoteException {
        System.out.println(object.processRequest(1, String.valueOf(loggedInEmployeeID)));
    }

    private static void updateEmployeeDetails(Interface object, Scanner scanner) throws RemoteException {
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        if (object.verifyEmployee(loggedInEmployeeID, firstName, lastName)) {
            System.out.println("Employee verified. Choose the field to update:");
            System.out.println("1. IC");
            System.out.println("2. Spouse Name");
            System.out.println("3. Spouse Contact");
            System.out.println("4. Spouse Email");
            System.out.println("5. Emergency Contact Name");
            System.out.println("6. Emergency Contact Relationship");
            System.out.println("7. Emergency Contact Phone");
            System.out.print("Enter your choice: ");
            int fieldChoice = scanner.nextInt();
            scanner.nextLine();

            String field;
            switch (fieldChoice) {
                case 1:
                    field = "IC";
                    break;
                case 2:
                    field = "SPOUSE_NAME";
                    break;
                case 3:
                    field = "SPOUSE_CONTACT";
                    break;
                case 4:
                    field = "SPOUSE_EMAIL";
                    break;
                case 5:
                    field = "EMERGENCY_CONTACT_NAME";
                    break;
                case 6:
                    field = "EMERGENCY_CONTACT_RELATIONSHIP";
                    break;
                case 7:
                    field = "EMERGENCY_CONTACT_PHONE";
                    break;
                default:
                    System.out.println("Invalid field choice.");
                    return;
            }

            System.out.print("Enter new value for " + field + ": ");
            String newValue = scanner.nextLine();
            System.out.println(object.updateSpecificField(loggedInEmployeeID, field, newValue));
        } else {
            System.out.println("Employee verification failed.");
        }
    }

    private static void applyForLeave(Interface object, Scanner scanner) throws RemoteException {
        System.out.print("Enter Leave Type: ");
        String leaveType = scanner.nextLine();
        System.out.print("Enter Start Date (YYYY-MM-DD): ");
        String startDate = scanner.nextLine();
        System.out.print("Enter End Date (YYYY-MM-DD): ");
        String endDate = scanner.nextLine();

        System.out.println(object.applyForLeave(String.valueOf(loggedInEmployeeID), leaveType, startDate, endDate));
    }

    private static void checkLeaveStatus(Interface object) throws RemoteException {
        System.out.println(object.checkLeaveStatus(String.valueOf(loggedInEmployeeID)));
    }

    private static void modifyLeaveApplication(Interface object, Scanner scanner) throws RemoteException {
        System.out.println("Fetching your pending leaves...");
        List<String> leaveDetails = object.viewPendingLeaves(loggedInEmployeeID);

        if (leaveDetails.isEmpty()) {
            System.out.println("No pending leaves found.");
            return;
        }

        System.out.println("Your Pending Leaves:");
        for (String leave : leaveDetails) {
            System.out.println(leave);
        }

        System.out.print("Enter Leave ID to modify: ");
        int leaveID = scanner.nextInt();
        scanner.nextLine();

        System.out.println("What would you like to modify?");
        System.out.println("1. Leave Type");
        System.out.println("2. Start Date");
        System.out.println("3. End Date");
        System.out.print("Enter choice (1/2/3): ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        String fieldToModify = "";
        switch (choice) {
            case 1:
                fieldToModify = "LEAVE_TYPE";
                break;
            case 2:
                fieldToModify = "START_DATE";
                break;
            case 3:
                fieldToModify = "END_DATE";
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        System.out.print("Enter new value for " + fieldToModify + ": ");
        String newValue = scanner.nextLine();

        String result = object.modifyLeaveDetails(loggedInEmployeeID, leaveID, fieldToModify, newValue);
        System.out.println(result);
    }
}
