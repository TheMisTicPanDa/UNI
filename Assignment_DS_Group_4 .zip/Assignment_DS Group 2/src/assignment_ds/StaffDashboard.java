
package assignment_ds;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Vector;
import java.util.Map;
import java.util.HashMap;

public class StaffDashboard extends JFrame {
    private JPanel panel;

    public StaffDashboard() {
        System.out.println("StaffDashboard Constructor Called.");
        setTitle("Staff Dashboard");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        
        panel = new JPanel(new GridLayout(5, 1, 10, 10));

        JButton addEmployeeButton = new JButton("Add Employee");
        JButton updateLeaveStatusButton = new JButton("Update Leave Status");
        JButton generateReportButton = new JButton("Generate Leave Report");
        JButton viewAllEmployeesButton = new JButton("View All Employees");
        JButton editEmployeeDetailsButton = new JButton("Edit Employee Details");
        JButton logoutButton = new JButton("Logout");

        addEmployeeButton.addActionListener(e -> addEmployee());
        updateLeaveStatusButton.addActionListener(e -> updateLeaveStatus());
        generateReportButton.addActionListener(e -> generateLeaveReport());
        viewAllEmployeesButton.addActionListener(e -> viewAllEmployees());
        editEmployeeDetailsButton.addActionListener(e -> editEmployeeDetails());
        logoutButton.addActionListener(e -> logout());

        panel.add(addEmployeeButton);
        panel.add(updateLeaveStatusButton);
        panel.add(generateReportButton);
        panel.add(viewAllEmployeesButton);
        panel.add(editEmployeeDetailsButton);
        panel.add(logoutButton);

        add(panel);

        System.out.println("StaffDashboard UI setup complete.");
    }

    
    private void addEmployee() {
        JTextField idField = new JTextField();
        JTextField icField = new JTextField();
        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField spouseNameField = new JTextField();
        JTextField spouseContactField = new JTextField();
        JTextField spouseEmailField = new JTextField();
        JTextField emergencyContactNameField = new JTextField();
        JTextField emergencyContactRelationshipField = new JTextField();
        JTextField emergencyContactPhoneField = new JTextField();

        Object[] message = {
            "Employee ID:", idField,
            "IC:", icField,
            "First Name:", firstNameField,
            "Last Name:", lastNameField,
            "Spouse Name:", spouseNameField,
            "Spouse Contact:", spouseContactField,
            "Spouse Email:", spouseEmailField,
            "Emergency Contact Name:", emergencyContactNameField,
            "Emergency Contact Relationship:", emergencyContactRelationshipField,
            "Emergency Contact Phone:", emergencyContactPhoneField
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Enter Employee Details", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String username = generateUsername(firstNameField.getText(), lastNameField.getText());
            String password = generateRandomPassword();

            try (Connection conn = database.getConnection()) {
                String query = "INSERT INTO EMPLOYEE (EMPLOYEE_ID, IC, FIRST_NAME, LAST_NAME, SPOUSE_NAME, SPOUSE_CONTACT, SPOUSE_EMAIL, EMERGENCY_CONTACT_NAME, EMERGENCY_CONTACT_RELATIONSHIP, EMERGENCY_CONTACT_PHONE, USERNAME, PASSWORD) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                    pstmt.setInt(1, Integer.parseInt(idField.getText()));
                    pstmt.setString(2, icField.getText());
                    pstmt.setString(3, firstNameField.getText());
                    pstmt.setString(4, lastNameField.getText());
                    pstmt.setString(5, spouseNameField.getText());
                    pstmt.setString(6, spouseContactField.getText());
                    pstmt.setString(7, spouseEmailField.getText());
                    pstmt.setString(8, emergencyContactNameField.getText());
                    pstmt.setString(9, emergencyContactRelationshipField.getText());
                    pstmt.setString(10, emergencyContactPhoneField.getText());
                    pstmt.setString(11, username);
                    pstmt.setString(12, password);
                    pstmt.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Employee added successfully!\nUsername: " + username + "\nTemporary Password: " + password);
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error adding employee: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    
   private void updateLeaveStatus() {
    String employeeID = JOptionPane.showInputDialog(this, "Enter Employee ID to update leave status:");
    if (employeeID != null && !employeeID.isEmpty()) {
        try (Connection conn = database.getConnection()) {
            String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES WHERE EMPLOYEE_ID = ? AND STATUS = 'Pending'";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, Integer.parseInt(employeeID));
                ResultSet rs = pstmt.executeQuery();
                Vector<String> leaves = new Vector<>();
                while (rs.next()) {
                    leaves.add(rs.getString("LEAVE_ID") + " - " + rs.getString("LEAVE_TYPE") + " (" + rs.getString("STATUS") + ")");
                }

                if (leaves.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No pending leave requests found for this employee.", "No Leaves Found", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                String selectedLeave = (String) JOptionPane.showInputDialog(this, "Select a leave to update:", "Update Leave Status", JOptionPane.QUESTION_MESSAGE, null, leaves.toArray(), null);
                if (selectedLeave != null) {
                    String leaveID = selectedLeave.split(" - ")[0];

                    // Retrieve leave details
                    query = "SELECT START_DATE, END_DATE FROM LEAVES WHERE LEAVE_ID = ?";
                    try (PreparedStatement leaveStmt = conn.prepareStatement(query)) {
                        leaveStmt.setInt(1, Integer.parseInt(leaveID));
                        ResultSet leaveRs = leaveStmt.executeQuery();

                        if (leaveRs.next()) {
                            LocalDate startDate = leaveRs.getDate("START_DATE").toLocalDate();
                            LocalDate endDate = leaveRs.getDate("END_DATE").toLocalDate();
                            int leaveDays = (int) ChronoUnit.DAYS.between(startDate, endDate) + 1;

                            // Check if employee has enough leave balance
                            if (!hasSufficientLeaveBalance(Integer.parseInt(employeeID), leaveDays)) {
                                // Auto-decline leave request due to insufficient balance
                                updateLeaveStatusInDatabase(Integer.parseInt(leaveID), "Declined");
                                JOptionPane.showMessageDialog(this, "Leave request declined due to insufficient leave balance.", "Leave Declined", JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                            // Ask for new status
                            String newStatus = JOptionPane.showInputDialog(this, "Enter new status (Accepted/Declined):");
                            if (newStatus != null && (newStatus.equalsIgnoreCase("Accepted") || newStatus.equalsIgnoreCase("Declined"))) {
                                updateLeaveStatusInDatabase(Integer.parseInt(leaveID), newStatus);

                                // If approved, deduct leave balance
                                if (newStatus.equalsIgnoreCase("Accepted")) {
                                    updateLeaveBalance(Integer.parseInt(employeeID), leaveDays);
                                }

                                JOptionPane.showMessageDialog(this, "Leave status updated successfully!");
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}


    
    private void generateLeaveReport() {
    JTextField employeeIDField = new JTextField();
    JTextField yearField = new JTextField();

    Object[] message = {
        "Enter Employee ID:", employeeIDField,
        "Enter Year:", yearField
    };

    int option = JOptionPane.showConfirmDialog(null, message, "Generate Leave Report", JOptionPane.OK_CANCEL_OPTION);
    if (option == JOptionPane.OK_OPTION) {
        try {
            int employeeID = Integer.parseInt(employeeIDField.getText().trim());
            int year = Integer.parseInt(yearField.getText().trim());

            try (Connection connection = database.getConnection()) {
                if (connection == null) {
                    JOptionPane.showMessageDialog(this, "Database connection error.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String query = "SELECT LEAVE_ID, LEAVE_TYPE, START_DATE, END_DATE, STATUS FROM LEAVES " +
                        "WHERE EMPLOYEE_ID = ? AND CAST(SUBSTR(CAST(START_DATE AS CHAR(10)), 1, 4) AS INTEGER) = ?";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setInt(1, employeeID);
                    statement.setInt(2, year);
                    ResultSet resultSet = statement.executeQuery();

                    if (!resultSet.next()) {
                        JOptionPane.showMessageDialog(this, "No leave records found for Employee ID: " + employeeID + " in year " + year + ".", "Info", JOptionPane.INFORMATION_MESSAGE);
                        return;
                    }

                    StringBuilder report = new StringBuilder();
                    report.append("Leave History Report for Employee ID: ").append(employeeID).append(" (Year: ").append(year).append(")\n\n");
                    report.append("--------------------------------------------------------------------------------\n");
                    report.append("| Leave ID | Type       | Start Date  | End Date    | Status     | Days |\n");
                    report.append("--------------------------------------------------------------------------------\n");

                    int totalDays = 0, acceptedLeaves = 0, declinedLeaves = 0, pendingLeaves = 0;
                    Map<String, Integer> leaveTypeCount = new HashMap<>();

                    do {
                        int leaveId = resultSet.getInt("LEAVE_ID");
                        String leaveType = resultSet.getString("LEAVE_TYPE");
                        Date startDate = resultSet.getDate("START_DATE");
                        Date endDate = resultSet.getDate("END_DATE");
                        String status = resultSet.getString("STATUS");

                        LocalDate startLocalDate = startDate.toLocalDate();
                        LocalDate endLocalDate = endDate.toLocalDate();
                        int daysBetween = (int) ChronoUnit.DAYS.between(startLocalDate, endLocalDate.plusDays(1));

                        report.append(String.format("| %-8d | %-10s | %-12s | %-12s | %-10s | %-4d |\n",
                                leaveId, leaveType, startDate, endDate, status, daysBetween));

                        if ("Accepted".equalsIgnoreCase(status)) {
                            totalDays += daysBetween;
                            acceptedLeaves++;
                            leaveTypeCount.put(leaveType, leaveTypeCount.getOrDefault(leaveType, 0) + 1);
                        } else if ("Declined".equalsIgnoreCase(status)) {
                            declinedLeaves++;
                        } else if ("Pending".equalsIgnoreCase(status)) {
                            pendingLeaves++;
                        }
                    } while (resultSet.next());

                    report.append("--------------------------------------------------------------------------------\n\n");
                    report.append("Summary Statistics:\n");
                    report.append("- Total Leave Days: ").append(totalDays).append(" days\n");
                    report.append("- Average Leave Duration: ").append((acceptedLeaves > 0 ? String.format("%.2f days per leave", (double) totalDays / acceptedLeaves) : "N/A")).append("\n");
                    for (Map.Entry<String, Integer> entry : leaveTypeCount.entrySet()) {
                        report.append("- ").append(entry.getKey()).append(" Leaves: ").append(entry.getValue()).append(" record(s)\n");
                    }
                    report.append("- Number of Declined Leaves: ").append(declinedLeaves).append("\n");
                    report.append("- Number of Pending Leaves: ").append(pendingLeaves).append("\n");

                    JTextArea textArea = new JTextArea(report.toString());
                    textArea.setEditable(false);
                    textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
                    textArea.setMargin(new Insets(10, 10, 10, 10));

                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setPreferredSize(new Dimension(600, 400));

                    JOptionPane.showMessageDialog(this, scrollPane, "Leave Report", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numeric values.", "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}


   
    private void viewAllEmployees() {
        try (Connection conn = database.getConnection()) {
            String query = "SELECT EMPLOYEE_ID, FIRST_NAME, LAST_NAME FROM EMPLOYEE";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                ResultSet rs = pstmt.executeQuery();
                StringBuilder employees = new StringBuilder("Employee List:\n");
                while (rs.next()) {
                    employees.append(rs.getInt("EMPLOYEE_ID")).append(": ").append(rs.getString("FIRST_NAME")).append(" ").append(rs.getString("LAST_NAME")).append("\n");
                }
                JOptionPane.showMessageDialog(this, employees.toString(), "Employees", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    
    private String generateUsername(String firstName, String lastName) { return firstName.toLowerCase() + "." + lastName.toLowerCase(); }
    private String generateRandomPassword() { return "Temp1234!"; }

    private void editEmployeeDetails() {
        String employeeID = JOptionPane.showInputDialog(this, "Enter Employee ID to edit details:");
        if (employeeID != null && !employeeID.isEmpty()) {
            try (Connection conn = database.getConnection()) {
                String query = "SELECT * FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                    pstmt.setInt(1, Integer.parseInt(employeeID));
                    ResultSet rs = pstmt.executeQuery();
                    if (rs.next()) {
                        JTextField firstNameField = new JTextField(rs.getString("FIRST_NAME"));
                        JTextField lastNameField = new JTextField(rs.getString("LAST_NAME"));
                        JTextField spouseNameField = new JTextField(rs.getString("SPOUSE_NAME"));
                        JTextField spouseContactField = new JTextField(rs.getString("SPOUSE_CONTACT"));
                        JTextField spouseEmailField = new JTextField(rs.getString("SPOUSE_EMAIL"));
                        JTextField emergencyContactNameField = new JTextField(rs.getString("EMERGENCY_CONTACT_NAME"));
                        JTextField emergencyContactRelationshipField = new JTextField(rs.getString("EMERGENCY_CONTACT_RELATIONSHIP"));
                        JTextField emergencyContactPhoneField = new JTextField(rs.getString("EMERGENCY_CONTACT_PHONE"));

                        Object[] message = {
                            "First Name:", firstNameField,
                            "Last Name:", lastNameField,
                            "Spouse Name:", spouseNameField,
                            "Spouse Contact:", spouseContactField,
                            "Spouse Email:", spouseEmailField,
                            "Emergency Contact Name:", emergencyContactNameField,
                            "Emergency Contact Relationship:", emergencyContactRelationshipField,
                            "Emergency Contact Phone:", emergencyContactPhoneField
                        };

                        int option = JOptionPane.showConfirmDialog(null, message, "Edit Employee Details", JOptionPane.OK_CANCEL_OPTION);
                        if (option == JOptionPane.OK_OPTION) {
                            query = "UPDATE EMPLOYEE SET FIRST_NAME = ?, LAST_NAME = ?, SPOUSE_NAME = ?, SPOUSE_CONTACT = ?, SPOUSE_EMAIL = ?, EMERGENCY_CONTACT_NAME = ?, EMERGENCY_CONTACT_RELATIONSHIP = ?, EMERGENCY_CONTACT_PHONE = ? WHERE EMPLOYEE_ID = ?";
                            try (PreparedStatement updateStmt = conn.prepareStatement(query)) {
                                updateStmt.setString(1, firstNameField.getText());
                                updateStmt.setString(2, lastNameField.getText());
                                updateStmt.setString(3, spouseNameField.getText());
                                updateStmt.setString(4, spouseContactField.getText());
                                updateStmt.setString(5, spouseEmailField.getText());
                                updateStmt.setString(6, emergencyContactNameField.getText());
                                updateStmt.setString(7, emergencyContactRelationshipField.getText());
                                updateStmt.setString(8, emergencyContactPhoneField.getText());
                                updateStmt.setInt(9, Integer.parseInt(employeeID));
                                updateStmt.executeUpdate();
                                JOptionPane.showMessageDialog(this, "Employee details updated successfully!");
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "No employee found with ID: " + employeeID);
                    }
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            }
        }
    }
    
    private boolean hasSufficientLeaveBalance(int employeeID, int leaveDays) {
    String checkBalanceQuery = "SELECT LEAVE_BALANCE FROM EMPLOYEE WHERE EMPLOYEE_ID = ?";
    try (Connection connection = database.getConnection();
         PreparedStatement statement = connection.prepareStatement(checkBalanceQuery)) {

        statement.setInt(1, employeeID);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            int leaveBalance = resultSet.getInt("LEAVE_BALANCE");
            return leaveBalance >= leaveDays;
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error checking leave balance: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    return false;
}


private void updateLeaveStatusInDatabase(int leaveIdToUpdate, String newStatus) {
    String updateStatusQuery = "UPDATE LEAVES SET STATUS = ? WHERE LEAVE_ID = ?";
    try (Connection connection = database.getConnection();
         PreparedStatement updateStmt = connection.prepareStatement(updateStatusQuery)) {

        updateStmt.setString(1, newStatus);
        updateStmt.setInt(2, leaveIdToUpdate);

        int rowsAffected = updateStmt.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Leave status updated to " + newStatus, "Update Successful", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update leave status.", "Update Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error updating leave status: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}

private void updateLeaveBalance(int employeeID, int leaveDays) {
    String updateBalanceQuery = "UPDATE EMPLOYEE SET LEAVE_BALANCE = LEAVE_BALANCE - ? WHERE EMPLOYEE_ID = ?";
    try (Connection connection = database.getConnection();
         PreparedStatement updateStmt = connection.prepareStatement(updateBalanceQuery)) {

        updateStmt.setInt(1, leaveDays);
        updateStmt.setInt(2, employeeID);

        int rowsAffected = updateStmt.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Leave balance updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update leave balance.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error updating leave balance: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}

    
    private void logout() {
    int confirm = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to logout?",
        "Logout Confirmation",
        JOptionPane.YES_NO_OPTION
    );

    if (confirm == JOptionPane.YES_OPTION) {
        JOptionPane.showMessageDialog(this, "You have successfully logged out. Redirecting to Login...");

        
        this.dispose();

       
        SwingUtilities.invokeLater(() -> {
            new EmployeeLogin().setVisible(true);
        });
    }
}

    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            System.out.println("Launching StaffDashboard directly...");
            StaffDashboard dashboard = new StaffDashboard();
            dashboard.setVisible(true);
        });
    }
}
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

