
package assignment_ds;


import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RMIRegistry {
    
    
    public static void main (String args[]) throws RemoteException
    {
        Registry reg = LocateRegistry.createRegistry(1044);
        reg.rebind("HRMService", new Server());
        System.out.println("RMI Registry started");

    }
}



