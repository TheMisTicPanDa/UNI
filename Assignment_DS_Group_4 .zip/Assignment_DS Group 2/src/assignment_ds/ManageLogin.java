package assignment_ds;

import java.io.*;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class ManageLogin implements Serializable {
    private static final String USER_DATA_FILE = "users.ser";
    private static HashMap<String, UserData> users = new HashMap<>();
    private static int loggedInEmployeeID = -1; // To hold the ID of the logged-in employee

    static {
        loadUserData();
    }

    // UserData class to store the user details
    public static class UserData implements Serializable {
        private String password;
        private String userType;
        private int employeeID;

        public UserData(String password, String userType, int employeeID) {
            this.password = password;
            this.userType = userType;
            this.employeeID = employeeID;
        }

        public String getPassword() {
            return password;
        }

        public String getUserType() {
            return userType;
        }

        public int getEmployeeID() {
            return employeeID;
        }
    }

    // Register a new user
/*public static void register(String username, String password, String userType, int employeeID) {
    if (users.containsKey(employeeID)) {
        System.out.println("employeeID already exists. Try logging in.");
        return;
    }

    // Store password, userType, and employeeID in the UserData object
    users.put(username, new UserData(password, userType, employeeID));
    saveUserData(); // Save the updated HashMap to the file
    System.out.println("Registration successful! Username: " + username);
    System.out.println("User Type: " + userType); // Display user type for logging
}*/
    public static void register(String username, String password, String userType, int employeeID) {
    try (Connection connection = database.getConnection()) {
        String query = "INSERT INTO USERS (USER_ID, USERTYPE, USERNAME, PASSWORD) VALUES (?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, employeeID);
        statement.setString(2, userType);
        statement.setString(3, username);
        statement.setString(4, password);
        statement.executeUpdate();

        // Also store it in users.ser for caching
        users.put(username, new UserData(password, userType, employeeID));
        saveUserData();

        System.out.println("Registration successful! Username: " + username);
    } catch (SQLException e) {
        System.out.println("Database error while registering: " + e.getMessage());
    }
}


public static boolean login(String username, String password) {
    try (Connection connection = database.getConnection()) {
        String query = "SELECT USER_ID, USERTYPE, PASSWORD FROM USERS WHERE USERNAME = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, username);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String storedPassword = resultSet.getString("PASSWORD");

            if (storedPassword.equals(password)) {
                int userId = resultSet.getInt("USER_ID");
                String userType = resultSet.getString("USERTYPE");

                // Store in users map for caching
                users.put(username, new UserData(storedPassword, userType, userId));
                saveUserData();

                loggedInEmployeeID = userId; // Save logged-in user ID
                System.out.println("Login successful! Welcome, " + username + ".");
                return true;
            }
        }
    } catch (SQLException e) {
        System.out.println("Database error during login: " + e.getMessage());
    }

    System.out.println("Invalid credentials. Please try again.");
    return false;
}


    // Login functionality
  /*  public static boolean login(String username, String password) {
    if (users.containsKey(username)) {
        UserData userData = users.get(username);
        if (userData.getPassword().equals(password)) {
            System.out.println("Login successful! Welcome, " + username + ".");
            loggedInEmployeeID = userData.getEmployeeID(); // Store employeeID
            return true;
        }
    }
    System.out.println("Invalid credentials. Please try again.");
    return false;
} */
//

    // Get the user type of the logged-in user
    public static String getUserType(String username) {
        if (users.containsKey(username)) {
            return users.get(username).getUserType(); // Correct method to access userType
        }
        return null;
    }

    // Load user data from file
    private static void loadUserData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(USER_DATA_FILE))) {
            users = (HashMap<String, UserData>) ois.readObject();
            System.out.println("User data loaded successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("User data file not found. Starting fresh...");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Save user data to file (Serialization)
    private static void saveUserData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USER_DATA_FILE))) {
            oos.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static int getEmployeeIDByUsername(String username) {
    if (users.containsKey(username)) {
        return users.get(username).getEmployeeID();
    }
    return -1; // Return -1 if the username is not found
}


    // Get the ID of the logged-in employee
    public static int getLoggedInEmployeeID() {
        return loggedInEmployeeID;
    }

    // Reset the logged-in employee ID
    public static void resetLoggedInEmployeeID() {
        loggedInEmployeeID = -1;
    }
    
}
