// admin_cli.rs
use tokio::net::TcpStream;
use tokio::io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader};
use tokio::io::stdin;
use std::io::Write;

fn print_menu() {
    println!("\n--- Traffic System Admin CLI ---");
    println!("1. Check current traffic status");
    println!("2. Generate traffic trend report");
    println!("3. Manual intervention (adjust traffic lights)");
    println!("4. Exit");
    print!("Enter your choice: ");
    std::io::stdout().flush().unwrap();
}

#[tokio::main]
async fn main() {
    loop {
        print_menu();

        let mut input = String::new();
        // Use a BufReader for asynchronous input.
        let mut reader = BufReader::new(stdin());
        reader.read_line(&mut input).await.unwrap();
        println!("DEBUG: Received input: {:?}", input.trim());
        let choice = input.trim();

        if choice == "4" {
            println!("Exiting admin CLI.");
            break;
        }

        let command_str = match choice {
            "1" => "status".to_string(),
            "2" => "report".to_string(),
            "3" => {
                print!("Enter manual intervention command: ");
                std::io::stdout().flush().unwrap();
                let mut manual_input = String::new();
                reader.read_line(&mut manual_input).await.unwrap();
                format!("control set {}", manual_input.trim())
            }
            _ => {
                println!("Invalid option. Please try again.");
                continue;
            }
        };

        // Connect to the TCP admin server.
        match TcpStream::connect("127.0.0.1:7878").await {
            Ok(mut stream) => {
                // Send the command.
                if let Err(e) = stream.write_all(command_str.as_bytes()).await {
                    eprintln!("Failed to send command: {}", e);
                    continue;
                }

                // Read the response.
                let mut buffer = vec![0; 4096];
                match stream.read(&mut buffer).await {
                    Ok(n) if n > 0 => {
                        println!("DEBUG: Received {} bytes", n);
                        let response = String::from_utf8_lossy(&buffer[..n]);
                        println!("Response:\n{}", response);
                    }
                    Ok(_) => {
                        println!("No response received.");
                    }
                    Err(e) => {
                        eprintln!("Failed to read response: {}", e);
                    }
                }
            }
            Err(e) => {
                eprintln!("Failed to connect to admin server: {}", e);
            }
        }
    }
}
