// use tokio::net::{TcpListener, TcpStream};
// use tokio::io::{AsyncReadExt, AsyncWriteExt};
// use std::sync::{Arc, Mutex};

// use chrono::{Utc, DateTime};
// use std::collections::HashMap;

// //
// // --- Traffic Aggregator (Component 4 data store) ---
// //
// #[derive(Debug, Clone, Copy)]
// pub enum LightState {
//     Red,
//     Green,
//     Yellow,
// }
// pub struct TrafficAggregator {
//     pub vehicle_counts: HashMap<u32, u32>,
//     pub delay_averages: HashMap<u32, f64>,
//     pub congestion_counts: HashMap<u32, u32>,
//     pub event_logs: Vec<String>,
//     pub light_states: HashMap<u32, LightState>,
//     pub light_timings: HashMap<u32, (u32, u32)>,
//     congestion_threshold: u32,

// }

// impl TrafficAggregator {
//     pub fn new() -> Self {
//         Self {
//             vehicle_counts: HashMap::new(),
//             delay_averages: HashMap::new(),
//             congestion_counts: HashMap::new(),
//             event_logs: Vec::new(),
//             light_states: HashMap::new(),
//             light_timings: HashMap::new(),
//             congestion_threshold: 10,

//         }
//     }

//     pub fn get_all_light_states(&self) -> HashMap<u32, LightState> {
//         self.light_states.clone()
//     }
//     pub fn update_light_state(&mut self, intersection_id: u32, state: LightState) {
//         self.light_states.insert(intersection_id, state);
//         self.log_event(format!("Intersection {} light changed to {:?}", intersection_id, state));
//     }

//     pub fn set_light_timings(&mut self, intersection_id: u32, green: u32, red: u32) {
//         self.light_timings.insert(intersection_id, (green, red));
//         self.log_event(format!("Intersection {} timings set to G:{}s R:{}s",
//             intersection_id, green, red));
//     }

//     pub fn log_event(&mut self, message: String) {
//         let timestamp: DateTime<Utc> = Utc::now();
//         self.event_logs.push(format!("[{}] {}", timestamp, message));
//     }

//     pub fn update_vehicle_count(&mut self, intersection_id: u32, count: i32) {
//         let entry = self.vehicle_counts.entry(intersection_id).or_insert(0);
//         *entry = (*entry as i32 + count).max(0) as u32;
//     }

//     pub fn update_delay(&mut self, intersection_id: u32, delay: u64) {
//         let alpha = 0.2; // Smoothing factor
//         let entry = self.delay_averages.entry(intersection_id).or_insert(0.0);

//         if *entry == 0.0 {
//             *entry = delay as f64;
//         } else {
//             *entry = alpha * delay as f64 + (1.0 - alpha) * (*entry);
//         }
//     }

//     pub fn generate_report(&self) -> String {
//         let mut report = String::from("🚦 **Traffic System Overview Report** 🚦\n\n");

//         report.push_str("📊 **Vehicle Counts Per Intersection:**\n");
//         for (intersection, count) in &self.vehicle_counts {
//             report.push_str(&format!("  - Intersection {}: {} vehicles\n", intersection, count));
//         }

//         report.push_str("\n⏳ **Average Delays Per Intersection:**\n");
//         for (intersection, avg_delay) in &self.delay_averages {
//             report.push_str(&format!("  - Intersection {}: {:.2} sec avg delay\n", intersection, avg_delay));
//         }

//         report.push_str("\n🚦 **Traffic Light States:**\n");
//         if self.light_states.is_empty() {
//             report.push_str("  - No light state data available\n");
//         } else {
//             for (intersection, state) in &self.light_states {
//                 let timing = self.light_timings.get(intersection)
//                     .map(|(g, r)| format!("(G:{}s/R:{}s)", g, r))
//                     .unwrap_or_default();

//                 let emoji = match state {
//                     LightState::Red => "🔴",
//                     LightState::Green => "🟢",
//                     LightState::Yellow => "🟡",
//                 };

//                 report.push_str(&format!(
//                     "  - {} Intersection {}: {:?} {}\n",
//                     emoji, intersection, state, timing
//                 ));
//             }
//         }

//         report.push_str(&format!("\n⚠️ **Congestion Alerts (Vehicles > {}):**\n", self.congestion_threshold));
//         let mut congested_intersections: Vec<_> = self.vehicle_counts.iter()
//             .filter(|(_, &count)| count > self.congestion_threshold)
//             .collect();

//         congested_intersections.sort_by(|a, b| b.1.cmp(a.1));

//         if congested_intersections.is_empty() {
//             report.push_str("  - No intersections currently congested\n");
//         } else {
//             for (intersection, count) in congested_intersections {
//                 let severity = if *count > 30 { "🚨 SEVERE" }
//                              else if *count > 20 { "🔴 HIGH" }
//                              else { "🟠 MEDIUM" };
//                 report.push_str(&format!("  - {} Intersection {}: {} vehicles\n", severity, intersection, count));
//             }
//         }

//         report.push_str("\n📝 **Recent Events:**\n");
//         for log in self.event_logs.iter().rev().take(5) {
//             report.push_str(&format!("  - {}\n", log));
//         }

//         report
//     }
// }

// //
// // --- Admin Command Parsing ---
// //

// #[derive(Debug)]
// enum AdminCommand {
//     Status,              // e.g. "status"
//     Report,              // e.g. "report"
//     ForceLight { command: String }, // e.g. "control set <parameters>"
//     Invalid,           // Unrecognized command
// }

// fn parse_command(command_str: &str) -> AdminCommand {
//     let parts: Vec<&str> = command_str.trim().split_whitespace().collect();
//     if parts.is_empty() {
//         return AdminCommand::Invalid;
//     }
//     match parts[0] {
//         "status" => AdminCommand::Status,
//         "report" => AdminCommand::Report,
//         "control" if parts.len() >= 3 && parts[1] == "set" => {
//             // Everything after "control set" is taken as the manual command.
//             let command = parts[2..].join(" ");
//             AdminCommand::ForceLight { command }
//         }
//         _ => AdminCommand::Invalid,
//     }
// }

// //
// // --- Connection Handler ---
// //

// async fn handle_connection(mut stream: TcpStream, aggregator: Arc<Mutex<TrafficAggregator>>) {
//     let mut buffer = vec![0; 4096];
//     match stream.read(&mut buffer).await {
//         Ok(n) if n == 0 => return,
//         Ok(n) => {
//             let command_str = String::from_utf8_lossy(&buffer[..n]).to_string();
//             println!("Received command: {:?}", command_str.trim());
//             let command = parse_command(&command_str);

//             // Generate response while holding the lock as briefly as possible
//             let response = {
//                 match command {
//                     AdminCommand::Status => {
//                         let agg = aggregator.lock().unwrap();
//                         format!(
//                             "Status: {} intersections, {} events logged",
//                             agg.vehicle_counts.len(),
//                             agg.event_logs.len()
//                         )
//                     }
//                     AdminCommand::Report => {
//                         let agg = aggregator.lock().unwrap();
//                         agg.generate_report()
//                     }
//                     AdminCommand::ForceLight { command } => {
//                         // Perform the mutation in a separate scope
//                         {
//                             let mut agg = aggregator.lock().unwrap();
//                             agg.log_event(format!("Manual intervention: {}", command));
//                         }
//                         format!("Manual intervention executed: {}", command)
//                     }
//                     AdminCommand::Invalid => "Invalid command received.".to_string(),
//                 }
//             };

//             // Write response after lock is released
//             if let Err(e) = stream.write_all(response.as_bytes()).await {
//                 eprintln!("Failed to write response: {}", e);
//             }
//         }
//         Err(e) => {
//             eprintln!("Failed to read from connection: {}", e);
//         }
//     }
// }

// //
// // --- Main for Admin Server ---
// //

// #[tokio::main]
// async fn main() -> std::io::Result<()> {
//     // Create the aggregator.
//     // In your full system, this aggregator should be updated by external components (e.g., the Traffic Simulation Engine).
//     let aggregator = Arc::new(Mutex::new(TrafficAggregator::new()));

//     // Do NOT preload dummy data here; the aggregator should reflect live traffic status.
//     // For testing, you might spawn a task that updates the aggregator periodically,
//     // but in production these updates come from your simulation/analysis components.

//     let listener = TcpListener::bind("127.0.0.1:7878").await?;
//     println!("Admin server listening on 127.0.0.1:7878");

//     loop {
//         let (stream, addr) = listener.accept().await?;
//         println!("Accepted connection from: {:?}", addr);
//         let agg_clone = Arc::clone(&aggregator);
//         tokio::spawn(async move {
//             handle_connection(stream, agg_clone).await;
//         });
//     }
// }

use chrono::{DateTime, Utc};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

// --- Traffic Light State ---
#[derive(Debug, Clone, Copy)]
pub enum LightState {
    Red,
    Green,
    Yellow,
}

// --- Traffic Aggregator ---
pub struct TrafficAggregator {
    pub vehicle_counts: HashMap<u32, u32>,
    pub delay_averages: HashMap<u32, f64>,
    pub congestion_counts: HashMap<u32, u32>,
    pub event_logs: Vec<String>,
    pub light_states: HashMap<u32, LightState>,
    pub light_timings: HashMap<u32, (u32, u32)>,
    congestion_threshold: u32,
}

impl TrafficAggregator {
    pub fn new() -> Self {
        Self {
            vehicle_counts: HashMap::new(),
            delay_averages: HashMap::new(),
            congestion_counts: HashMap::new(),
            event_logs: Vec::new(),
            light_states: HashMap::new(),
            light_timings: HashMap::new(),
            congestion_threshold: 10,
        }
    }

    pub fn update_light_state(&mut self, intersection_id: u32, state: LightState) {
        self.light_states.insert(intersection_id, state);
        self.log_event(format!(
            "Admin changed intersection {} light to {:?}",
            intersection_id, state
        ));
    }

    pub fn set_light_timings(&mut self, intersection_id: u32, green: u32, red: u32) {
        self.light_timings.insert(intersection_id, (green, red));
        self.log_event(format!(
            "Admin set intersection {} timings to G:{}s R:{}s",
            intersection_id, green, red
        ));
    }

    pub fn log_event(&mut self, message: String) {
        let timestamp: DateTime<Utc> = Utc::now();
        self.event_logs.push(format!("[{}] {}", timestamp, message));
    }

    pub fn generate_report(&self) -> String {
        let mut report = String::from("🚦 Traffic System Report\n\n");

        // Light States Section
        // 🚦 **Traffic Light States Report**
        report.push_str("\n🚦 **Traffic Light States:**\n");
        if self.light_states.is_empty() {
            report.push_str("  - No light state data available\n");
        } else {
            let mut intersections: Vec<_> = self.light_states.keys().collect();
            intersections.sort();

            for &intersection in intersections {
                let state = self.light_states[&intersection];
                let timing = self
                    .light_timings
                    .get(&intersection)
                    .map(|(g, r)| format!("(G:{}s/R:{}s)", g, r))
                    .unwrap_or_else(|| "(Timing not set)".to_string());

                let emoji = match state {
                    LightState::Red => "🔴",
                    LightState::Green => "🟢",
                    LightState::Yellow => "🟡",
                };

                report.push_str(&format!(
                    "  - {} Intersection {}: {:?} {}\n",
                    emoji, intersection, state, timing
                ));
            }
        }

        report.push_str("📊 **Vehicle Counts Per Intersection:**\n");
        for (intersection, count) in &self.vehicle_counts {
            report.push_str(&format!(
                "  - Intersection {}: {} vehicles\n",
                intersection, count
            ));
        }

        report.push_str("\n⏳ **Average Delays Per Intersection:**\n");
        for (intersection, avg_delay) in &self.delay_averages {
            report.push_str(&format!(
                "  - Intersection {}: {:.2} sec avg delay\n",
                intersection, avg_delay
            ));
        }

        report.push_str(&format!(
            "\n⚠️ **Congestion Alerts (Vehicles > {}):**\n",
            self.congestion_threshold
        ));
        let mut congested_intersections: Vec<_> = self
            .vehicle_counts
            .iter()
            .filter(|(_, &count)| count > self.congestion_threshold)
            .collect();
        congested_intersections.sort_by(|a, b| b.1.cmp(a.1));

        if congested_intersections.is_empty() {
            report.push_str("  - No intersections currently congested\n");
        } else {
            for (intersection, count) in congested_intersections {
                let severity = if *count > 30 {
                    "🚨 SEVERE"
                } else if *count > 20 {
                    "🔴 HIGH"
                } else {
                    "🟠 MEDIUM"
                };
                report.push_str(&format!(
                    "  - {} Intersection {}: {} vehicles\n",
                    severity, intersection, count
                ));
            }
        }

        report.push_str("\n📝 **Recent Events:**\n");
        for log in self.event_logs.iter().rev().take(5) {
            report.push_str(&format!("  - {}\n", log));
        }

        // Other sections (vehicle counts, delays, etc.)...
        report
    }
}

// --- Admin Commands ---
#[derive(Debug)]
enum AdminCommand {
    Status,
    Report,
    SetLightState { id: u32, state: LightState },
    SetLightTiming { id: u32, green: u32, red: u32 },
    Help,
    Invalid,
}

fn parse_command(input: &str) -> AdminCommand {
    let parts: Vec<&str> = input.trim().split_whitespace().collect();
    if parts.is_empty() {
        return AdminCommand::Invalid;
    }

    match parts[0].to_lowercase().as_str() {
        "status" => AdminCommand::Status,
        "report" => AdminCommand::Report,
        "set-light" if parts.len() == 3 => {
            match (parts[1].parse(), parts[2].to_lowercase().as_str()) {
                (Ok(id), "red") => AdminCommand::SetLightState {
                    id,
                    state: LightState::Red,
                },
                (Ok(id), "green") => AdminCommand::SetLightState {
                    id,
                    state: LightState::Green,
                },
                (Ok(id), "yellow") => AdminCommand::SetLightState {
                    id,
                    state: LightState::Yellow,
                },
                _ => AdminCommand::Invalid,
            }
        }
        "set-timing" if parts.len() == 4 => {
            match (parts[1].parse(), parts[2].parse(), parts[3].parse()) {
                (Ok(id), Ok(green), Ok(red)) => AdminCommand::SetLightTiming { id, green, red },
                _ => AdminCommand::Invalid,
            }
        }
        "help" => AdminCommand::Help,
        _ => AdminCommand::Invalid,
    }
}

// --- Connection Handler ---
async fn handle_connection(mut stream: TcpStream, aggregator: Arc<Mutex<TrafficAggregator>>) {
    let mut buffer = [0; 1024];

    match stream.read(&mut buffer).await {
        Ok(n) if n == 0 => return,
        Ok(n) => {
            let command = String::from_utf8_lossy(&buffer[..n]);
            let response = match parse_command(&command) {
                AdminCommand::Status => {
                    let agg = aggregator.lock().unwrap();
                    format!("Status: {} intersections monitored", agg.light_states.len())
                }
                AdminCommand::Report => {
                    let agg = aggregator.lock().unwrap();
                    agg.generate_report()
                }
                AdminCommand::SetLightState { id, state } => {
                    let mut agg = aggregator.lock().unwrap();
                    agg.update_light_state(id, state);
                    format!("Changed intersection {} to {:?}", id, state)
                }
                AdminCommand::SetLightTiming { id, green, red } => {
                    let mut agg = aggregator.lock().unwrap();
                    agg.set_light_timings(id, green, red);
                    format!("Set intersection {} timing to G:{}s R:{}s", id, green, red)
                }
                AdminCommand::Help => String::from(
                    "Available commands:\n\
                    - status: Get system status\n\
                    - report: Generate full report\n\
                    - set-light <id> <red|green|yellow>: Change light state\n\
                    - set-timing <id> <green_sec> <red_sec>: Change light timing\n\
                    - help: Show this help",
                ),
                AdminCommand::Invalid => String::from("Invalid command. Type 'help' for options."),
            };

            if let Err(e) = stream.write_all(response.as_bytes()).await {
                eprintln!("Failed to send response: {}", e);
            }
        }
        Err(e) => eprintln!("Failed to read from connection: {}", e),
    }
}

// --- Main Server ---
#[tokio::main]
async fn main() -> std::io::Result<()> {
    // Initialize with some sample intersections
    let aggregator = Arc::new(Mutex::new({
        let mut agg = TrafficAggregator::new();
        // Add some default intersections
        for id in 1..=4 {
            agg.light_states.insert(id, LightState::Red);
            agg.light_timings.insert(id, (30, 30));
        }
        agg
    }));

    let listener = TcpListener::bind("127.0.0.1:7878").await?;
    println!("Admin server running on 127.0.0.1:7878");

    loop {
        let (stream, _) = listener.accept().await?;
        let agg = Arc::clone(&aggregator);
        tokio::spawn(async move {
            handle_connection(stream, agg).await;
        });
    }
}
