use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum VehicleType {
    Car,
    Bus,
    Truck,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Vehicle {
    pub id: u32,
    pub vehicle_type: VehicleType,
    pub speed: u32,  // Speed in km/h
    pub route: Vec<(u32, u32)>,  // List of grid coordinates
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum TrafficEvent {
    Arrival { vehicle: Vehicle },
    Departure { vehicle_id: u32 },
    Incident { location: (u32, u32), description: String },
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct IntersectionState {
    pub location: (u32, u32),
    pub vehicle_count: usize,
    pub delays: u32,  // Average delay in seconds
}
