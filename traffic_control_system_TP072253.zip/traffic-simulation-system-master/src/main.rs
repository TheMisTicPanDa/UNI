mod components;

use components::system_monitoring_reporting::data_aggregator::TrafficAggregator;
use components::system_monitoring_reporting::monitoring_report::{EventLogger, LogEvent};
use components::traffic_control_system::control::control_system;
use components::traffic_flow_analyzer::analysis::run_analysis;
use components::traffic_simulation_engine::traffic_event::{EventType, TrafficEvent};
use components::traffic_simulation_engine::traffic_grid::TrafficGrid;
use components::traffic_simulation_engine::traffic_light::TrafficState;
use tokio::time::{interval, Duration};

use chrono::Local;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::sync::{broadcast, Mutex};

/// Define admin commands.
#[derive(Debug)]
enum AdminCommand {
    Status,
    Report,
    ForceLight { command: String },
    Invalid,
}

/// Simple parser for admin command strings.
fn parse_command(command_str: &str) -> AdminCommand {
    let parts: Vec<&str> = command_str.trim().split_whitespace().collect();
    if parts.is_empty() {
        return AdminCommand::Invalid;
    }
    match parts[0] {
        "status" => AdminCommand::Status,
        "report" => AdminCommand::Report,
        "control" if parts.len() >= 3 && parts[1] == "set" => {
            let command = parts[2..].join(" ");
            AdminCommand::ForceLight { command }
        }
        _ => AdminCommand::Invalid,
    }
}

#[tokio::main]
async fn main() -> std::io::Result<()> {
    // Initialize communication channels
    let (event_tx, _) = broadcast::channel::<TrafficEvent>(100);
    let (congestion_tx, congestion_rx) = broadcast::channel::<String>(100);
    let (control_tx, control_rx) = broadcast::channel::<String>(100);

    // Initialize core components
    let traffic_grid: Arc<TrafficGrid> = Arc::new(TrafficGrid::new(4).await);
    let aggregator: Arc<Mutex<TrafficAggregator>> = Arc::new(Mutex::new(TrafficAggregator::new()));
    let logger = Arc::new(Mutex::new(EventLogger::new(
        "logs/traffic.json",
        "logs/traffic.csv",
    )?));

    // Spawn the admin server as a task within the simulation.
    {
        let aggregator_admin = aggregator.clone();
        tokio::spawn(async move {
            let listener = TcpListener::bind("127.0.0.1:7878")
                .await
                .expect("Failed to bind admin server");
            println!("Admin server listening on 127.0.0.1:7878");
            loop {
                let (mut stream, addr) = listener
                    .accept()
                    .await
                    .expect("Failed to accept connection");
                println!("Admin server accepted connection from {:?}", addr);
                let aggregator_admin = aggregator_admin.clone();
                tokio::spawn(async move {
                    let mut buffer = vec![0; 1024];
                    match stream.read(&mut buffer).await {
                        Ok(n) if n == 0 => return, // Connection closed.
                        Ok(n) => {
                            let command_str = String::from_utf8_lossy(&buffer[..n]).to_string();
                            println!("Admin server received command: {:?}", command_str.trim());
                            let command = parse_command(&command_str);
                            let response = match command {
                                AdminCommand::Status => {
                                    let agg = aggregator_admin.lock().await;
                                    format!(
                                        "Status: {} intersections, {} events logged",
                                        agg.vehicle_counts.len(),
                                        agg.event_logs.len()
                                    )
                                }
                                AdminCommand::Report => {
                                    let agg = aggregator_admin.lock().await;
                                    agg.generate_report()
                                }
                                AdminCommand::ForceLight { command } => {
                                    let mut agg = aggregator_admin.lock().await;
                                    agg.log_event(format!("Manual intervention: {}", command));
                                    format!("Manual intervention executed: {}", command)
                                }
                                AdminCommand::Invalid => "Invalid command received.".to_string(),
                            };
                            if let Err(e) = stream.write_all(response.as_bytes()).await {
                                eprintln!("Failed to write response: {}", e);
                            }
                        }
                        Err(e) => {
                            eprintln!("Failed to read from connection: {}", e);
                        }
                    }
                });
            }
        });
    }

    // Clone necessary components for tasks
    let traffic_grid_clone = traffic_grid.clone();
    let traffic_grid_clone2 = traffic_grid.clone();
    let traffic_grid_clone3 = traffic_grid.clone();
    let aggregator_clone = aggregator.clone();
    let aggregator_clone2 = aggregator.clone();
    let logger_clone = logger.clone();

    // Spawn all system components
    let tasks = vec![
        // Traffic simulation
        tokio::spawn({
            let tx = event_tx.clone();
            async move {
                traffic_grid.simulate_traffic(tx).await;
            }
        }),
        // Traffic light control
        tokio::spawn({
            let grid = traffic_grid_clone;
            async move {
                grid.process_traffic_lights().await;
            }
        }),
        // Traffic analysis
        tokio::spawn({
            let rx = event_tx.subscribe();
            let congestion_tx = congestion_tx.clone();
            let control_tx = control_tx.clone();
            let aggregator = aggregator_clone;
            async move {
                run_analysis(rx, aggregator, control_tx, congestion_tx).await;
            }
        }),
        // Control system
        tokio::spawn({
            let grid = traffic_grid_clone2;
            let aggregator = aggregator.clone();
            async move {
                control_system(control_rx, grid, aggregator).await;
            }
        }),
        // Event display
        tokio::spawn({
            let mut rx = event_tx.subscribe();
            async move {
                while let Ok(event) = rx.recv().await {
                    match event.event_type {
                        EventType::VehicleArrival => {
                            println!(
                                "[🚗 ARRIVAL] Vehicle {} arrived at Intersection {}",
                                event.vehicle_id.unwrap_or(0),
                                event.intersection_id
                            );
                        }
                        EventType::VehicleDeparture => {
                            println!(
                                "[🏁 DEPARTURE] Vehicle {} left Intersection {}",
                                event.vehicle_id.unwrap_or(0),
                                event.intersection_id
                            );
                        }
                        EventType::Incident(ref details) => {
                            println!(
                                "[⚠️ INCIDENT] {} at Intersection {} | Delay: {} seconds",
                                details,
                                event.intersection_id,
                                event.delay_seconds.unwrap_or(0)
                            );
                        }
                        EventType::VehicleRerouted => {
                            println!(
                                "[🔄 REROUTE] Vehicle {} rerouted at Intersection {}",
                                event.vehicle_id.unwrap_or(0),
                                event.intersection_id
                            );
                        }
                        EventType::IncidentStarted => {
                            println!(
                                "[⚠️ INCIDENT START] Intersection {} blocked | Delay: {} seconds",
                                event.intersection_id,
                                event.delay_seconds.unwrap_or(0)
                            );
                        }
                        EventType::IncidentCleared => {
                            println!(
                                "[✅ INCIDENT CLEARED] Intersection {} reopened",
                                event.intersection_id
                            );
                        }
                    }
                }
            }
        }),
        // Congestion alert display
        tokio::spawn({
            let mut rx = congestion_rx.resubscribe();
            async move {
                while let Ok(alert) = rx.recv().await {
                    println!("{}", alert);
                }
            }
        }),
        // // Event logging
        // tokio::spawn({
        //     let mut rx = event_tx.subscribe();
        //     let logger = logger_clone;
        //     async move {
        //         while let Ok(event) = rx.recv().await {
        //             let current_time = Local::now().format("%H:%M:%S").to_string();
        //             let log_event = match event.event_type {
        //                 EventType::VehicleArrival => LogEvent::TrafficEvent {
        //                     intersection_id: event.intersection_id,
        //                     vehicle_count: 1,
        //                     time: current_time.clone(),
        //                 },
        //                 EventType::VehicleDeparture => LogEvent::TrafficEvent {
        //                     intersection_id: event.intersection_id,
        //                     vehicle_count: -1,
        //                     time: current_time.clone(),
        //                 },
        //                 EventType::Incident(_) => LogEvent::CongestionAlert {
        //                     intersection_id: event.intersection_id,
        //                     severity: 3,
        //                     predicted_delay_sec: event.delay_seconds.unwrap_or(0) as u32,
        //                     time: current_time.clone(),
        //                 },
        //                 _ => continue, // Skip other event types for logging
        //             };

        //             if let Err(e) = logger.lock().await.log_event(&log_event) {
        //                 eprintln!("Failed to log event: {}", e);
        //             }
        //         }
        //     }
        // }),

        // // Light state monitoring
        // tokio::spawn({
        //     let grid = traffic_grid_clone3.clone();
        //     let logger = logger.clone();
        //     async move {
        //         let mut interval = tokio::time::interval(Duration::from_secs(1));
        //         loop {
        //             interval.tick().await;
        //             let current_time = Local::now().format("%H:%M:%S").to_string();

        //             for (id, intersection) in grid.get_intersections() {
        //                 let intersection = intersection.lock().await;
        //                 for (light_idx, light) in intersection.traffic_lights.iter().enumerate() {
        //                     let light = light.lock().await;

        //                     // Extract the number of seconds from the `Duration`
        //                     let duration_sec = light.green_duration.as_secs() as u32;

        //                     let _ = logger.lock().await.log_event(&LogEvent::LightStateChange {
        //                         intersection_id: *id,
        //                         light_id: light_idx as u8,
        //                         new_state: match light.state {
        //                             TrafficState::Green => "green".to_string(),
        //                             TrafficState::Red => "red".to_string(),
        //                         },
        //                         duration_sec, // Using the extracted seconds as u32
        //                         time: current_time.clone(),
        //                     });
        //                 }
        //             }

        //         }
        //     }
        // }),

        // Event logging
        tokio::spawn({
            let mut rx = event_tx.subscribe();
            let logger = logger_clone;
            async move {
                while let Ok(event) = rx.recv().await {
                    match event.event_type {
                        EventType::VehicleArrival => {
                            if let Some(vehicle_id) = event.vehicle_id {
                                if let Err(e) = logger.lock().await.log_vehicle_event(
                                    "arrival",
                                    event.intersection_id,
                                    vehicle_id,
                                ) {
                                    eprintln!("Failed to log vehicle arrival: {}", e);
                                }
                            }
                        }
                        EventType::VehicleDeparture => {
                            if let Some(vehicle_id) = event.vehicle_id {
                                if let Err(e) = logger.lock().await.log_vehicle_event(
                                    "departure",
                                    event.intersection_id,
                                    vehicle_id,
                                ) {
                                    eprintln!("Failed to log vehicle departure: {}", e);
                                }
                            }
                        }
                        EventType::Incident(description) => {
                            if let Err(e) = logger.lock().await.log_incident(
                                event.intersection_id,
                                description,
                                event.delay_seconds.unwrap_or(0) as u32,
                                // Estimate affected vehicles as current count + 5
                                *logger
                                    .lock()
                                    .await
                                    .vehicle_counts
                                    .get(&event.intersection_id)
                                    .unwrap_or(&0)
                                    + 5,
                            ) {
                                eprintln!("Failed to log incident: {}", e);
                            }
                        }
                        _ => {} // Skip other event types
                    }
                }
            }
        }),
        // Light state monitoring with queue tracking
        tokio::spawn({
            let grid = traffic_grid_clone3.clone();
            let logger = logger.clone();
            async move {
                let mut interval = tokio::time::interval(Duration::from_secs(1));
                // Change to store String instead of &str
                let mut previous_states: HashMap<(u32, usize), String> = HashMap::new();

                loop {
                    interval.tick().await;

                    for (id, intersection) in grid.get_intersections() {
                        let intersection = intersection.lock().await;
                        let current_vehicles =
                            *logger.lock().await.vehicle_counts.get(id).unwrap_or(&0);

                        for (light_idx, light) in intersection.traffic_lights.iter().enumerate() {
                            let light = light.lock().await;
                            let current_state = match light.state {
                                TrafficState::Green => "green".to_string(),
                                TrafficState::Red => "red".to_string(),
                            };

                            // Get previous state as string reference
                            let previous_state = previous_states
                                .get(&(*id, light_idx))
                                .map(|s| s.as_str())
                                .unwrap_or("unknown");

                            // Only log if state changed or it's been 30 seconds
                            let should_log = previous_state != current_state.as_str();

                            if should_log {
                                let queue_length = match light.state {
                                    TrafficState::Red => {
                                        current_vehicles / intersection.traffic_lights.len() as u32
                                    }
                                    TrafficState::Green => 0, // Queue is clearing when green
                                };

                                if let Err(e) = logger.lock().await.log_light_change(
                                    *id,
                                    light_idx as u8,
                                    previous_state.to_string(), // Convert &str to String
                                    current_state.clone(),      // Clone the String
                                    light.green_duration.as_secs() as u32,
                                    queue_length,
                                ) {
                                    eprintln!("Failed to log light change: {}", e);
                                }

                                // Store the String in the HashMap
                                previous_states.insert((*id, light_idx), current_state.clone());
                            }
                        }
                    }
                }
            }
        }),
        tokio::spawn({
            let logger = logger.clone();
            let aggregator = aggregator_clone2.clone();
            async move {
                let mut interval = interval(Duration::from_secs(10));
                loop {
                    interval.tick().await;
                    let aggregator = aggregator.lock().await;

                    // Calculate system-wide metrics
                    let total_vehicles: u32 = logger.lock().await.vehicle_counts.values().sum();

                    // Get congested intersections and store their IDs
                    let congested_intersections: Vec<u32> = aggregator
                        .congestion_counts
                        .iter()
                        .filter(|&(_, &v)| v > 0) // Filter intersections with congestion
                        .map(|(&id, _)| id) // Collect the IDs of congested intersections
                        .collect();

                    let average_delay = aggregator.average_delays();

                    // Log system summary (total vehicles, number of congested intersections, and average delay)
                    if let Err(e) = logger.lock().await.log_system_summary(
                        total_vehicles,
                        congested_intersections.len() as u32,
                        average_delay,
                    ) {
                        eprintln!("Failed to log system summary: {}", e);
                    }

                    // First, make sure you have the current vehicle counts available
                    let mut logger_guard = logger.lock().await;

                    // Log congestion for each affected intersection
                    for &intersection_id in &congested_intersections {
                        if let Err(e) = logger_guard.log_congestion_alert(intersection_id) {
                            eprintln!(
                                "Failed to log congestion alert for intersection {}: {}",
                                intersection_id, e
                            );
                        }
                    }

                    // If you also want to log the overall congestion summary (optional)
                    if let Err(e) = logger_guard.log_system_summary(
                        total_vehicles,
                        congested_intersections.len() as u32,
                        average_delay,
                    ) {
                        eprintln!("Failed to log system summary: {}", e);
                    }
                }
            }
        }),
        // Periodic reporting
        tokio::spawn({
            let aggregator = aggregator_clone2;
            async move {
                let mut interval = interval(Duration::from_secs(20));
                loop {
                    interval.tick().await;
                    let report = aggregator.lock().await.generate_report();
                    println!("{}", report);
                }
            }
        }),
    ];

    // Wait for all tasks to complete
    futures::future::join_all(tasks).await;
    Ok(())
}
