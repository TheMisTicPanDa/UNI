use crate::components::traffic_simulation_engine::traffic_grid::TrafficGrid;
use std::sync::Arc;
use tokio::sync::broadcast;
use crate::components::system_monitoring_reporting::data_aggregator::TrafficAggregator;


pub async fn control_system(
    mut control_receiver: broadcast::Receiver<String>,
    traffic_grid: Arc<TrafficGrid>,
    aggregator: Arc<tokio::sync::Mutex<TrafficAggregator>>
) {
    println!("[CONTROL SYSTEM] Started.");
    while let Ok(control_info) = control_receiver.recv().await {
        let collection: Vec<&str> = control_info.split(" ").collect();
        let intersection_id = collection[0].parse::<u32>().unwrap();
        let predicted_traffic = collection[1].parse::<u64>().unwrap();

        let expected_delay = predicted_traffic * 2; // Example: 2 seconds per vehicle
        aggregator.lock().await.update_delay(intersection_id, expected_delay);

        println!("[CONTROL SYSTEM] Received control info: {}", control_info);

        let collection: Vec<&str> = control_info.split(" ").collect();
        if collection.len() != 2 {
            println!(
                "[CONTROL SYSTEM] Invalid control info format: {}",
                control_info
            );
            continue;
        }

        let intersection_id = match collection[0].parse::<u32>() {
            Ok(id) => id,
            Err(_) => {
                println!(
                    "[CONTROL SYSTEM] Failed to parse intersection ID: {}",
                    collection[0]
                );
                continue;
            }
        };

        let predicted_traffic = match collection[1].parse::<u64>() {
            Ok(traffic) => traffic,
            Err(_) => {
                println!(
                    "[CONTROL SYSTEM] Failed to parse predicted traffic: {}",
                    collection[1]
                );
                continue;
            }
        };

        let intersections = traffic_grid.get_intersections();
        if let Some(intersection) = intersections.get(&intersection_id) {
            println!(
                "[CONTROL SYSTEM] Found intersection with ID: {}",
                intersection_id
            );
            println!(
                "[CONTROL SYSTEM] Attempting to lock intersection {}",
                intersection_id
            );
            let intersection = intersection.lock().await;
            println!(
                "[CONTROL SYSTEM] Successfully locked intersection {}",
                intersection_id
            );

            let extension_time = std::cmp::min(predicted_traffic, 20);
            println!(
                "[🚦 EXTENSION] Traffic Lights at Intersection {} have been extended by {} seconds.",
                intersection_id, extension_time
            );

            let mut aggregator = aggregator.lock().await;
            aggregator.log_event(format!(
                "Extended lights at {} by {} sec due to traffic",
                intersection_id, extension_time
            ));
            
            // Adjust each traffic light at the intersection:
            for n in 0..4 {
                let mut light = intersection.traffic_lights[n].lock().await;
                light.change_green_light_duration(extension_time).await;
            }
        } else {
            println!(
                "[CONTROL SYSTEM] Intersection ID {} not found.",
                intersection_id
            );
        }
    }
}
