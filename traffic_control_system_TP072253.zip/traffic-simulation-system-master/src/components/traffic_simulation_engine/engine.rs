use crate::common::data_model::{TrafficEvent, Vehicle, VehicleType};
use tokio::sync::mpsc::Sender;
use rand::{Rng, SeedableRng};
use rand::rngs::StdRng; // Thread-safe RNG
use std::time::Duration;

pub async fn start_simulation(sender: Sender<TrafficEvent>, grid_size: (u32, u32)) {
    // Use StdRng to ensure thread-safety
    let mut rng = StdRng::from_entropy();

    loop {
        let vehicle = Vehicle {
            id: rng.gen(),
            vehicle_type: if rng.gen_bool(0.7) { VehicleType::Car } else { VehicleType::Bus },
            speed: rng.gen_range(20..100),
            route: vec![(rng.gen_range(0..grid_size.0), rng.gen_range(0..grid_size.1))],
        };

        let event = TrafficEvent::Arrival { vehicle };
        if let Err(err) = sender.send(event).await {
            eprintln!("Failed to send event: {}", err);
        }

        tokio::time::sleep(Duration::from_secs(1)).await; // Simulate time delay
    }
}
