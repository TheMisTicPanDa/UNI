use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum EventType {
    VehicleArrival,
    VehicleDeparture,
    VehicleRerouted, // Add this new variant
    IncidentStarted, // Add this new variant
    IncidentCleared,
    Incident(String), // e.g., "Accident" or "Stalled Vehicle"



}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TrafficEvent {
    pub intersection_id: u32,
    pub vehicle_id: Option<u32>,
    pub event_type: EventType,
    pub delay_seconds: Option<u64>,
}
