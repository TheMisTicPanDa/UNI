use std::sync::Arc;
use tokio::sync::Mutex;
use tokio::time::{Duration, Instant};

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum TrafficState {
    Red,
    Green,
}

pub struct TrafficLight {
    pub state: TrafficState,
    /// The current green phase duration.
    pub green_duration: Duration,
    /// How long the red phase lasts.
    pub red_duration: Duration,
    pub last_update: Instant,
    /// Minimum allowable green duration.
    pub min_green: Duration,
    /// Maximum allowable green duration.
    pub max_green: Duration,
}

impl TrafficLight {
    /// Creates a new TrafficLight.
    /// - `min_green`: minimum green time in seconds.
    /// - `max_green`: maximum green time in seconds.
    /// - `red_duration`: red time in seconds.
    pub fn new(min_green: u64, max_green: u64, red_duration: u64) -> Self {
        TrafficLight {
            // Start in red by default.
            state: TrafficState::Red,
            green_duration: Duration::from_secs(min_green),
            red_duration: Duration::from_secs(red_duration),
            last_update: Instant::now(),
            min_green: Duration::from_secs(min_green),
            max_green: Duration::from_secs(max_green),
        }
    }




    /// Update the light state based on elapsed time.
    /// If GREEN for at least green_duration, switch to RED.
    /// If RED for at least red_duration, switch to GREEN.
    pub fn update(&mut self) {
        let now = Instant::now();
        let elapsed = now.duration_since(self.last_update);
        // Optional debug: print elapsed time.
        // println!("[DEBUG] Elapsed time: {}s", elapsed.as_secs());

        match self.state {
            TrafficState::Green => {
                if elapsed >= self.green_duration {
                    println!(
                        "[🔄 TRANSITION] Switching from GREEN to RED after {}s",
                        elapsed.as_secs()
                    );
                    self.state = TrafficState::Red;
                    self.last_update = now;
                }
            }
            TrafficState::Red => {
                if elapsed >= self.red_duration {
                    println!(
                        "[🔄 TRANSITION] Switching from RED to GREEN after {}s",
                        elapsed.as_secs()
                    );
                    self.state = TrafficState::Green;
                    self.last_update = now;
                }
            }
        }
    }

    /// Display the current state of the traffic light.
    pub fn display(&self, intersection_id: u32, light_id: usize) {
        let state_str = match self.state {
            TrafficState::Red => "🔴 RED",
            TrafficState::Green => "🟢 GREEN",
        };
        println!(
            "[🚦 TRAFFIC LIGHT] Intersection: {}, Light: {}, State: {}, Green Duration: {}s, Red Duration: {}s",
            intersection_id,
            light_id,
            state_str,
            self.green_duration.as_secs(),
            self.red_duration.as_secs()
        );
    }

    

    /// The continuous run loop for a traffic light.
    pub async fn run_loop(
        arc_self: Arc<Mutex<TrafficLight>>,
        intersection_id: u32,
        light_id: usize,
    ) {
        loop {
            {
                let mut light = arc_self.lock().await;
                light.update();
                light.display(intersection_id, light_id);
            }
            tokio::time::sleep(Duration::from_secs(1)).await;
        }
    }

    /// Adjust the green duration based on external control.
    pub async fn change_green_light_duration(&mut self, extra_time: u64) {
        let new_duration = self.green_duration + Duration::from_secs(extra_time);
        self.green_duration = new_duration.min(self.max_green);
        self.last_update = Instant::now();
        println!(
            "[⚙️ CONTROL] Adjusted green duration to {}s",
            self.green_duration.as_secs()
        );
    }

   
}
