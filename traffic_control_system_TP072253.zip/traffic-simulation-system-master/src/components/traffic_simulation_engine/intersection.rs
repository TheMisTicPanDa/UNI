use super::traffic_event::{EventType, TrafficEvent};
use super::traffic_grid::TrafficGrid;
use super::traffic_light::{TrafficLight, TrafficState};
use super::vehicle::Vehicle;
use rand::Rng;
use std::collections::VecDeque;
use std::sync::Arc;
use tokio::sync::broadcast::{self, Sender};
use tokio::sync::Mutex;

pub struct Intersection {
    pub id: u32,
    pub is_edge: bool,
    pub vehicles: VecDeque<Vehicle>,
    pub traffic_lights: Vec<Arc<Mutex<TrafficLight>>>,
    pub has_incident: bool,
    pub incident_delay: u64,
}

impl Intersection {
    pub async fn new(id: u32, is_edge: bool) -> Self {
        let traffic_lights = vec![
            Arc::new(Mutex::new(TrafficLight::new(10, 30, 2))),
            Arc::new(Mutex::new(TrafficLight::new(10, 30, 3))),
            Arc::new(Mutex::new(TrafficLight::new(10, 30, 4))),
            Arc::new(Mutex::new(TrafficLight::new(10, 30, 2))),
        ];

        Intersection {
            id,
            is_edge,
            vehicles: VecDeque::new(),
            traffic_lights,
            has_incident: false,
            incident_delay: 0,
        }
    }

    /// Trigger an incident at the intersection.
    pub fn trigger_incident(&mut self, delay: u64, grid_size: u32, rng: &mut impl Rng, sender: &Sender<TrafficEvent>) {
        self.has_incident = true;
        self.incident_delay = delay;

        let _ = sender.send(TrafficEvent {
            intersection_id: self.id,
            vehicle_id: None,
            event_type: EventType::IncidentStarted,
            delay_seconds: Some(delay),
        });

        // Reroute all vehicles that would pass through this intersection
        for vehicle in &mut self.vehicles {
            if vehicle.route.contains(&self.id) {
                println!(
                    "[🔄 REROUTING] Vehicle {} rerouting around blocked intersection {}",
                    vehicle.id, self.id
                );
                vehicle.reroute_around(self.id, grid_size, rng);

                let _ = sender.send(TrafficEvent {
                    intersection_id: self.id,
                    vehicle_id: Some(vehicle.id),
                    event_type: EventType::VehicleRerouted,
                    delay_seconds: None,
                });
            }
        }

        println!(
            "[⚠️ INCIDENT] Intersection {} blocked. Rerouting vehicles. Delay: {}s",
            self.id, delay
        );
    }
}
pub async fn process_vehicle_queue(
    intersection_id: u32,
    traffic_lights: Vec<Arc<Mutex<TrafficLight>>>,
    vehicles: Vec<Vehicle>,
    sender: &broadcast::Sender<TrafficEvent>,
    grid: &Arc<TrafficGrid>,
) {
    // First, check for an incident at this intersection.
    if let Some(intersection_arc) = grid.get_intersections().get(&intersection_id) {
        let mut intersection = intersection_arc.lock().await;
        if intersection.has_incident {
            println!(
                "[⛔ INCIDENT] Intersection {} has an incident. Delaying vehicles for {} seconds.",
                intersection.id, intersection.incident_delay
            );
            tokio::time::sleep(std::time::Duration::from_secs(intersection.incident_delay)).await;
            // Reset the incident flag after handling.
           
            let _ = sender.send(TrafficEvent {
                intersection_id: intersection.id,
                vehicle_id: None,
                event_type: EventType::IncidentCleared,
                delay_seconds: None,
            });            
            intersection.has_incident = false;
        }
    }

    let mut sorted_vehicles = vehicles;
    // Sort: vehicles with fewer remaining intersections first, then by priority.
    sorted_vehicles.sort_by(|a, b| {
        a.remaining_intersections()
            .cmp(&b.remaining_intersections())
            .then(a.priority.cmp(&b.priority))
    });

    // Congestion check: if vehicles exceed a threshold, log a congestion message.
    let congestion_threshold = 5;
    if sorted_vehicles.len() >= congestion_threshold {
        println!(
            "🚨 Congestion at Intersection {}: {} vehicles waiting",
            intersection_id,
            sorted_vehicles.len()
        );
    }

    for mut vehicle in sorted_vehicles {
        let traffic_light_index = vehicle.direction;
        let light_arc = &traffic_lights[traffic_light_index];

        // Wait (with exponential backoff) until the relevant light turns green.
        let mut wait_delay = 100;
        loop {
            let light = light_arc.lock().await;
            if light.state == TrafficState::Green {
                break;
            }
            drop(light);
            tokio::time::sleep(std::time::Duration::from_millis(wait_delay)).await;
            wait_delay = std::cmp::min(wait_delay * 2, 1000);
        }

        // Reduced travel delays.
        let travel_delay = match vehicle.vehicle_type {
            crate::components::traffic_simulation_engine::vehicle::VehicleType::Car => 1, // was 2
            crate::components::traffic_simulation_engine::vehicle::VehicleType::Bus => 2, // was 4
            crate::components::traffic_simulation_engine::vehicle::VehicleType::Truck => 3, // was 6
        };

        println!(
            "[🚙 MOVING] Vehicle {} ({:?}) passing Intersection {} via Light {} (Delay: {}s)",
            vehicle.id, vehicle.vehicle_type, intersection_id, traffic_light_index, travel_delay
        );

        tokio::time::sleep(std::time::Duration::from_secs(travel_delay)).await;

        if let Some(next_intersection_id) = vehicle.move_to_next_intersection() {
            let vid = vehicle.id;
            let _ = sender.send(TrafficEvent {
                intersection_id,
                vehicle_id: Some(vid),
                event_type: EventType::VehicleDeparture,
                delay_seconds: None,
            });
            if let Some(next_intersection_arc) = grid.get_intersections().get(&next_intersection_id)
            {
                let mut next_int = next_intersection_arc.lock().await;
                next_int.vehicles.push_back(vehicle);
            }
            let _ = sender.send(TrafficEvent {
                intersection_id: next_intersection_id,
                vehicle_id: Some(vid),
                event_type: EventType::VehicleArrival,
                delay_seconds: None,
            });
        } else {
            println!(
                "[✅ COMPLETED] Vehicle {} has completed its route.",
                vehicle.id
            );
        }
    }
}
