use rand::Rng;
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Debug, Clone)]

pub enum VehicleType {
    Car,
    Bus,
    Truck,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Vehicle {
    pub id: u32,
    pub vehicle_type: VehicleType,
    pub speed: u32,      // Speed in km/h
    pub route: Vec<u32>, // List of intersection IDs representing the path
    pub current_intersection: u32,
    pub priority: u32,    // Priority level
    pub direction: usize, // 0=North, 1=South, 2=East, 3=West
}

impl Vehicle {
    // Modified to accept a mutable RNG
    pub fn new<T: Rng + ?Sized>(
        id: u32,
        vehicle_type: VehicleType,
        speed: u32,
        priority: u32,
        grid_size: u32,
        start: u32,
        rng: &mut T,
    ) -> Self {
        let destination = Self::generate_random_edge_destination(start, grid_size, rng);
        let route = Self::generate_route(start, destination, grid_size);
        let direction: usize = Self::determine_direction(start, destination, grid_size);

        Vehicle {
            id,
            vehicle_type,
            speed,
            route,
            current_intersection: start,
            priority,
            direction,
        }
    }

    pub fn remaining_intersections(&self) -> usize {
        if let Some(pos) = self
            .route
            .iter()
            .position(|&x| x == self.current_intersection)
        {
            if pos + 1 < self.route.len() {
                self.route.len() - pos - 1
            } else {
                0
            }
        } else {
            self.route.len()
        }
    }
    // New helper function to generate a destination different from the start
    fn generate_random_edge_destination<T: Rng + ?Sized>(
        start: u32,
        grid_size: u32,
        rng: &mut T,
    ) -> u32 {
        let edge_intersections = Self::get_edge_intersections(grid_size);
        let possible_destinations: Vec<u32> = edge_intersections
            .into_iter()
            .filter(|&x| x != start)
            .collect();
        possible_destinations[rng.random_range(0..possible_destinations.len())]
    }

    // Modified to use the provided RNG instead of thread_rng()
    #[allow(dead_code)]
    fn generate_random_edge_route<T: Rng + ?Sized>(grid_size: u32, rng: &mut T) -> (u32, u32) {
        let edge_intersections = Self::get_edge_intersections(grid_size);

        let start = edge_intersections[rng.random_range(0..edge_intersections.len())];
        let mut destination = edge_intersections[rng.random_range(0..edge_intersections.len())];

        // Ensure the destination is different from the start
        while destination == start {
            destination = edge_intersections[rng.random_range(0..edge_intersections.len())];
        }

        (start, destination)
    }

    /// Get all edge intersections in the grid
    fn get_edge_intersections(grid_size: u32) -> Vec<u32> {
        let mut edges = Vec::new();
        for i in 0..grid_size {
            for j in 0..grid_size {
                if i == 0 || i == grid_size - 1 || j == 0 || j == grid_size - 1 {
                    edges.push(i * grid_size + j);
                }
            }
        }
        edges
    }

    /// Generate a route from start to destination
    fn generate_route(start: u32, destination: u32, grid_size: u32) -> Vec<u32> {
        let mut route = Vec::new();
        let start_row = start / grid_size;
        let start_col = start % grid_size;
        let dest_row = destination / grid_size;
        let dest_col = destination % grid_size;

        // Move horizontally first, then vertically
        if start_col < dest_col {
            for col in start_col..=dest_col {
                route.push(start_row * grid_size + col);
            }
        } else {
            for col in (dest_col..=start_col).rev() {
                route.push(start_row * grid_size + col);
            }
        }

        if start_row < dest_row {
            for row in start_row + 1..=dest_row {
                route.push(row * grid_size + dest_col);
            }
        } else {
            for row in (dest_row..start_row).rev() {
                route.push(row * grid_size + dest_col);
            }
        }

        route
    }

    pub fn route_to_string(&self) -> String {
        let result = self
            .route
            .iter()
            .map(|num| num.to_string()) // Convert each number to a string
            .collect::<Vec<String>>() // Collect into a vector of strings
            .join("-"); // Join with '-'
        result
    }
    pub fn reroute_around(&mut self, blocked_id: u32, grid_size: u32, rng: &mut impl Rng) {
        if !self.route.contains(&blocked_id) {
            return;
        }

        let blocked_idx = self.route.iter().position(|&x| x == blocked_id).unwrap();

        // Can't reroute if blocked intersection is current or final destination
        if blocked_idx == 0 || blocked_idx == self.route.len() - 1 {
            return;
        }

        let before_blocked = self.route[..blocked_idx].to_vec();
        let after_blocked = self.route[blocked_idx + 1..].to_vec();

        let last_safe = before_blocked.last().unwrap();
        let next_target = after_blocked.first().unwrap();

        // Find alternative path that avoids the blocked intersection
        let detour = self.find_detour(*last_safe, *next_target, blocked_id, grid_size, rng);

        // Update the route
        self.route = before_blocked
            .into_iter()
            .chain(detour)
            .chain(after_blocked)
            .collect();

        // Update direction based on new route
        if let Some(&next_intersection) = self.route.get(blocked_idx) {
            self.direction =
                Self::determine_direction(self.current_intersection, next_intersection, grid_size);
        }

        println!(
            "[🔄 REROUTE] Vehicle {} changed route to: {} (avoiding {})",
            self.id,
            self.route_to_string(),
            blocked_id
        );
    }

    fn find_detour(
        &self,
        start: u32,
        end: u32,
        blocked: u32,
        grid_size: u32,
        rng: &mut impl Rng,
    ) -> Vec<u32> {
        let (start_row, start_col) = (start / grid_size, start % grid_size);
        let (end_row, end_col) = (end / grid_size, end % grid_size);
        let (block_row, block_col) = (blocked / grid_size, blocked % grid_size);

        let mut detour = Vec::new();

        // Try vertical then horizontal
        if rng.gen_bool(0.5) {
            // Vertical movement
            let row_step = if end_row > start_row { 1 } else { -1 };
            let mut current_row = start_row;
            while current_row != end_row {
                current_row = (current_row as i32 + row_step) as u32;
                let candidate = current_row * grid_size + start_col;
                if candidate != blocked {
                    detour.push(candidate);
                }
            }

            // Horizontal movement
            let col_step = if end_col > start_col { 1 } else { -1 };
            let mut current_col = start_col;
            while current_col != end_col {
                current_col = (current_col as i32 + col_step) as u32;
                let candidate = end_row * grid_size + current_col;
                if candidate != blocked {
                    detour.push(candidate);
                }
            }
        }
        // Try horizontal then vertical
        else {
            // Horizontal movement
            let col_step = if end_col > start_col { 1 } else { -1 };
            let mut current_col = start_col;
            while current_col != end_col {
                current_col = (current_col as i32 + col_step) as u32;
                let candidate = start_row * grid_size + current_col;
                if candidate != blocked {
                    detour.push(candidate);
                }
            }

            // Vertical movement
            let row_step = if end_row > start_row { 1 } else { -1 };
            let mut current_row = start_row;
            while current_row != end_row {
                current_row = (current_row as i32 + row_step) as u32;
                let candidate = current_row * grid_size + end_col;
                if candidate != blocked {
                    detour.push(candidate);
                }
            }
        }

        detour
    }

    pub fn move_to_next_intersection(&mut self) -> Option<u32> {
        let current_index = self
            .route
            .iter()
            .position(|&x| x == self.current_intersection)?;
        if current_index + 1 < self.route.len() {
            self.current_intersection = self.route[current_index + 1];
            Some(self.current_intersection)
        } else {
            None // Vehicle has reached its destination
        }
    }

    /// Determines the vehicle's movement direction based on its start and destination.
    /// 0 = Northbound, 1 = Southbound, 2 = Eastbound, 3 = Westbound
    pub fn determine_direction(start: u32, destination: u32, grid_size: u32) -> usize {
        let start_row = start / grid_size;
        let start_col = start % grid_size;
        let dest_row = destination / grid_size;
        let dest_col = destination % grid_size;

        if start_col == dest_col {
            if start_row < dest_row {
                return 2; // Moving South
            } else {
                return 0; // Moving North
            }
        } else {
            if start_col < dest_col {
                return 1; // Moving East
            } else {
                return 3; // Moving West
            }
        }
    }
}
