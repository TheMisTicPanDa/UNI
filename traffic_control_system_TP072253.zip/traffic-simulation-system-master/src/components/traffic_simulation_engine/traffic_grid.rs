use super::intersection::{process_vehicle_queue, Intersection};
use super::traffic_event::{EventType, TrafficEvent};
use super::traffic_light::TrafficLight;
use super::vehicle::{Vehicle, VehicleType};
use futures::future::join_all;
use rand::Rng;
use rand::SeedableRng;
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::Mutex;

pub struct TrafficGrid {
    intersections: HashMap<u32, Arc<Mutex<Intersection>>>,
    grid_size: u32,
}

impl TrafficGrid {
    pub async fn new(size: u32) -> Self {
        let mut intersections = HashMap::new();
        for i in 0..size {
            for j in 0..size {
                let id = i * size + j;
                let is_edge = i == 0 || i == size - 1 || j == 0 || j == size - 1;
                // Assume Intersection::new creates an intersection with its traffic_lights properly initialized.
                intersections.insert(
                    id,
                    Arc::new(Mutex::new(Intersection::new(id, is_edge).await)),
                );
            }
        }
        TrafficGrid {
            intersections,
            grid_size: size,
        }
    }

    pub fn get_intersections(&self) -> &HashMap<u32, Arc<Mutex<Intersection>>> {
        &self.intersections
    }

    /// Process all traffic lights by spawning a run_loop for each one.
    pub async fn process_traffic_lights(self: Arc<Self>) {
        let mut intersection_handles = vec![];

        for (intersection_id, intersection) in self.intersections.clone() {
            let intersection_clone = Arc::clone(&intersection);
            let handle = tokio::spawn(async move {
                let traffic_lights = {
                    let intersection = intersection_clone.lock().await;
                    intersection.traffic_lights.clone()
                };

                let mut light_handles = vec![];

                for (light_id, light) in traffic_lights.iter().enumerate() {
                    let light_clone = Arc::clone(&light);
                    let light_handle = tokio::spawn(async move {
                        TrafficLight::run_loop(light_clone, intersection_id, light_id).await;
                    });
                    light_handles.push(light_handle);
                }

                join_all(light_handles).await;
            });

            intersection_handles.push(handle);
        }

        join_all(intersection_handles).await;
    }

    pub async fn simulate_traffic(
        self: Arc<Self>,
        sender: tokio::sync::broadcast::Sender<TrafficEvent>,
    ) {
        // Initialize the StdRng in a block so that thread_rng is dropped immediately.
        let mut rng = {
            let mut rng_source = rand::rng();
            rand::rngs::StdRng::from_rng(&mut rng_source)
        };
        let mut vehicle_id = 0;

        loop {
            let intersections = self.intersections.clone();
            for (id, intersection_arc) in intersections.into_iter() {
                let sender_clone = sender.clone();
                let intersection_clone = intersection_arc.clone();
                let grid_clone = self.clone();
                tokio::spawn(async move {
                    let (vehicles, cloned_lights, has_incident, incident_delay) = {
                        let mut intersection = intersection_clone.lock().await;
                        if intersection.has_incident {
                            println!(
                                "[⛔ BLOCKED] Intersection {} has an incident. Vehicles delayed for {}s",
                                intersection.id, intersection.incident_delay
                            );
                            intersection.has_incident = false;
                            (
                                Vec::new(),
                                intersection.traffic_lights.clone(),
                                true,
                                intersection.incident_delay,
                            )
                        } else {
                            (
                                std::mem::take(&mut intersection.vehicles)
                                    .into_iter()
                                    .collect::<Vec<_>>(),
                                intersection.traffic_lights.clone(),
                                false,
                                0,
                            )
                        }
                    };
                    if has_incident {
                        tokio::time::sleep(std::time::Duration::from_secs(incident_delay)).await;
                    }
                    if !vehicles.is_empty() {
                        process_vehicle_queue(
                            id,
                            cloned_lights,
                            vehicles,
                            &sender_clone,
                            &grid_clone,
                        )
                        .await;
                    }
                });

                let mut intersection = intersection_arc.lock().await;

                // RANDOM INCIDENT TRIGGER:
                // With a 1% chance (or any chosen probability), trigger an incident if not already active.
                if rng.random_range(0..100) < 1 && !intersection.has_incident {
                    let delay = rng.random_range(2..=10);
                    intersection.trigger_incident(delay, self.grid_size, &mut rng, &sender);
                    // Updated call
                }

                if intersection.is_edge && rng.random_range(0..100) < 10 {
                    let vehicle_type = match rng.random_range(0..3) {
                        0 => VehicleType::Car,
                        1 => VehicleType::Bus,
                        2 => VehicleType::Truck,
                        _ => unreachable!(),
                    };

                    let speed = match vehicle_type {
                        VehicleType::Car => 60,
                        VehicleType::Bus => 40,
                        VehicleType::Truck => 30,
                    };

                    let priority = match vehicle_type {
                        VehicleType::Car => 1,
                        VehicleType::Bus => 2,
                        VehicleType::Truck => 3,
                    };

                    let vehicle = Vehicle::new(
                        vehicle_id,
                        vehicle_type,
                        speed,
                        priority,
                        self.grid_size,
                        id,
                        &mut rng,
                    );
                    vehicle_id += 1;
                    intersection.vehicles.push_back(vehicle.clone());

                    println!(
                        "[🚗 NEW VEHICLE] ID: {} | Type: {:?} | Speed: {} km/h | Priority: {} | Route: {}",
                        vehicle.id, vehicle.vehicle_type, speed, priority, vehicle.route_to_string()
                    );

                    let _ = sender.send(TrafficEvent {
                        intersection_id: id,
                        vehicle_id: Some(vehicle.id),
                        event_type: EventType::VehicleArrival,
                        delay_seconds: None,
                    });
                }
            }
            tokio::time::sleep(std::time::Duration::from_millis(500)).await;
        }
    }
}
