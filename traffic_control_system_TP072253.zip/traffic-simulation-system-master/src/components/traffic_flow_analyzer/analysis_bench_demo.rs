use crate::components::system_monitoring_reporting::data_aggregator::TrafficAggregator;
use crate::components::traffic_simulation_engine::traffic_event::{TrafficEvent, EventType};
use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, SystemTime};
use tokio::sync::{broadcast, Mutex};

/// Benchmark-friendly version of run_analysis that stops after `max_events`
pub async fn run_analysis_limited(
    mut traffic_receiver: broadcast::Receiver<TrafficEvent>,
    aggregator: Arc<Mutex<TrafficAggregator>>,
    congestion_sender: broadcast::Sender<String>,
    control_sender: broadcast::Sender<String>,
    max_events: usize,
) {
    let mut vehicle_arrival_time: HashMap<(u32, u32), SystemTime> = HashMap::new();
    let mut traffic_history: HashMap<u32, Vec<u32>> = HashMap::new();
    let mut delay_history: HashMap<u32, Vec<u64>> = HashMap::new();

    const PREDICTION: usize = 5;
    const WEIGHTS: [f32; PREDICTION] = [0.05, 0.1, 0.15, 0.25, 0.45];
    const CONGESTION_THRESHOLD: u32 = 10;
    const DELAY_THRESHOLD: u64 = 8;

    let mut processed = 0;

    while processed < max_events {
        if let Ok(event) = traffic_receiver.recv().await {
            processed += 1;
            let mut aggregator = aggregator.lock().await;

            match event.event_type {
                EventType::VehicleArrival => {
                    if let Some(vehicle_id) = event.vehicle_id {
                        vehicle_arrival_time.insert((event.intersection_id, vehicle_id), SystemTime::now());
                    }

                    aggregator.update_vehicle_count(event.intersection_id, 1);

                    let entry = traffic_history.entry(event.intersection_id).or_default();
                    entry.push(event.vehicle_id.unwrap_or(0));

                    let vehicle_count = entry.len() as u32;

                    let history = delay_history.entry(event.intersection_id).or_default();
                    history.push(vehicle_count as u64);
                    if history.len() > PREDICTION {
                        history.remove(0);
                    }

                    let predicted_traffic = if history.len() == PREDICTION {
                        history
                            .iter()
                            .zip(WEIGHTS.iter())
                            .map(|(count, weight)| *count as f32 * weight)
                            .sum::<f32>()
                            .round() as u32
                    } else {
                        vehicle_count
                    };

                    if predicted_traffic > CONGESTION_THRESHOLD {
                        aggregator.increment_congestion(event.intersection_id);
                        let msg = format!(
                            "Predicted congestion at {}: {} vehicles",
                            event.intersection_id, predicted_traffic
                        );
                        let _ = congestion_sender.send(msg);
                        let _ = control_sender.send(format!("{} {}", event.intersection_id, predicted_traffic));
                    }
                }

                EventType::VehicleDeparture => {
                    if let Some(vehicle_id) = event.vehicle_id {
                        if let Some(arrival_time) =
                            vehicle_arrival_time.remove(&(event.intersection_id, vehicle_id))
                        {
                            let delay = arrival_time.elapsed()
                                .unwrap_or(Duration::from_secs(0))
                                .as_secs();

                            aggregator.update_delay(event.intersection_id, delay);

                            if delay > DELAY_THRESHOLD {
                                let _ = congestion_sender.send(format!(
                                    "⚠️ High delay at {}: {}s",
                                    event.intersection_id, delay
                                ));
                            }
                        }
                    }

                    aggregator.update_vehicle_count(event.intersection_id, -1);

                    if let Some(entry) = traffic_history.get_mut(&event.intersection_id) {
                        entry.retain(|&id| Some(id) != event.vehicle_id);
                    }
                }

                _ => {
                    // For benchmarking, we skip handling other event types
                }
            }
        }
    }
}
