use crate::components::system_monitoring_reporting::data_aggregator::{
    LightState, TrafficAggregator,
};
use crate::components::traffic_simulation_engine::traffic_event::{EventType, TrafficEvent};
use crate::components::traffic_simulation_engine::traffic_light::TrafficLight;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, SystemTime};
use tokio::sync::{broadcast, Mutex};

// Main function to run the analysis
pub async fn run_analysis(
    mut traffic_receiver: broadcast::Receiver<TrafficEvent>,
    aggregator: Arc<Mutex<TrafficAggregator>>,
    congestion_sender: broadcast::Sender<String>,
    control_sender: broadcast::Sender<String>,
) {
    // Track the arrival times of each vehicle at different intersection
    let mut vehicle_arrival_time: HashMap<(u32, u32), SystemTime> = HashMap::new();

    // Track the traffic/delay history for prediction
    let mut traffic_history: HashMap<u32, Vec<u32>> = HashMap::new();
    let mut delay_history: HashMap<u32, Vec<u64>> = HashMap::new();

    const PREDICTION: usize = 5;
    const WEIGHTS: [f32; PREDICTION] = [0.05, 0.1, 0.15, 0.25, 0.45];

    const CONGESTION_THRESHOLD: u32 = 10;
    const DELAY_THRESHOLD: u64 = 8; 

    // ================= Listening for events =================
    // We use while loop to keep listening for new traffic events from the simulation engine

    while let Ok(event) = traffic_receiver.recv().await {
        let mut aggregator = aggregator.lock().await;

        match event.event_type {

            // ================= Vehicle Arrival Event =================
            EventType::VehicleArrival => {
                // Record arrival time to calculate delay
                if let Some(vehicle_id) = event.vehicle_id {
                    vehicle_arrival_time
                        .insert((event.intersection_id, vehicle_id), SystemTime::now());
                }

                // Update vehicle count
                aggregator.update_vehicle_count(event.intersection_id, 1);
                aggregator.log_event(format!(
                    "Vehicle arrived at intersection {}",
                    event.intersection_id
                ));

                // Traffic prediction
                let entry = traffic_history.entry(event.intersection_id).or_default();
                entry.push(event.vehicle_id.unwrap_or(0));

                let vehicle_count = entry.len() as u32;

                let history = delay_history.entry(event.intersection_id).or_default();
                history.push(vehicle_count as u64);
                if history.len() > PREDICTION {
                    history.remove(0);
                }

                let predicted_traffic = if history.len() == PREDICTION {
                    history
                        .iter()
                        .zip(WEIGHTS.iter())
                        .map(|(count, weight)| *count as f32 * weight)
                        .sum::<f32>()
                        .round() as u32
                } else {
                    vehicle_count
                };

                println!(
                    "🔍 Traffic Analysis: Intersection {}, Vehicles: {}, Predicted Next: {}",
                    event.intersection_id, vehicle_count, predicted_traffic
                );

                // Check for congestion
                if predicted_traffic > CONGESTION_THRESHOLD {
                    aggregator.increment_congestion(event.intersection_id);
                    let alert_message = format!(
                        "[ALERT]🚦 Predicted congestion at intersection {} in next 10 seconds. Estimated vehicles: {}",
                        event.intersection_id, predicted_traffic
                    );
                    congestion_sender.send(alert_message.clone()).unwrap();
                    aggregator.log_event(alert_message);
                    control_sender
                        .send(format!("{} {}", event.intersection_id, predicted_traffic))
                        .unwrap();
                }
            }

            // ================= Vehicle Departure Event =================
            EventType::VehicleDeparture => {
                // Calculate and record delay
                if let Some(vehicle_id) = event.vehicle_id {
                    if let Some(arrival_time) =
                        vehicle_arrival_time.remove(&(event.intersection_id, vehicle_id))
                    {
                        let delay = arrival_time
                            .elapsed()
                            .unwrap_or(Duration::from_secs(0))
                            .as_secs();

                        aggregator.update_delay(event.intersection_id, delay);

                        // Check if delay exceeds threshold (but don't count as congestion)
                        if delay > DELAY_THRESHOLD {
                            let alert_message = format!(
                                "⚠️ High delay at intersection {}: {} seconds",
                                event.intersection_id, delay
                            );
                            congestion_sender.send(alert_message.clone()).unwrap();
                            aggregator.log_event(alert_message);
                        }
                    }
                }

                // Update vehicle count
                aggregator.update_vehicle_count(event.intersection_id, -1);
                aggregator.log_event(format!(
                    "Vehicle departed from intersection {}",
                    event.intersection_id
                ));

                // Clean up traffic history
                if let Some(entry) = traffic_history.get_mut(&event.intersection_id) {
                    entry.retain(|&id| Some(id) != event.vehicle_id);
                }
            }

            // ================= Incident Detected Event =================
            EventType::Incident(description) => {
                let delay = event.delay_seconds.unwrap_or(5);
                aggregator.update_delay(event.intersection_id, delay);
                aggregator.increment_congestion(event.intersection_id);
                aggregator.log_event(format!(
                    "Incident at intersection {}: {} (Delay: {} seconds)",
                    event.intersection_id, description, delay
                ));

                let incident_message = format!(
                    "[ALERT] ⚠️ Incident detected at intersection {}: {}. Delay: {} seconds",
                    event.intersection_id, description, delay
                );
                congestion_sender.send(incident_message.clone()).unwrap();
                aggregator.log_event(incident_message);
                control_sender
                    .send(format!("{} 5", event.intersection_id))
                    .unwrap();
            }

            // ================= Vehicle Rerouted Event =================
            EventType::VehicleRerouted => {
                println!(
                    "[ANALYSIS] Vehicle {} rerouted at intersection {}",
                    event.vehicle_id.unwrap_or(0),
                    event.intersection_id
                );
                aggregator.log_event(format!(
                    "Vehicle {} rerouted at intersection {}",
                    event.vehicle_id.unwrap_or(0),
                    event.intersection_id
                ));
            }

            // ================= Incident Started Event =================
            EventType::IncidentStarted => {
                println!(
                    "[ANALYSIS] Incident started at intersection {}. Delay: {} seconds",
                    event.intersection_id,
                    event.delay_seconds.unwrap_or(0)
                );
                aggregator.log_event(format!(
                    "Incident started at intersection {}. Delay: {} seconds",
                    event.intersection_id,
                    event.delay_seconds.unwrap_or(0)
                ));

                // Clear predicted congestion for this intersection
                delay_history.remove(&event.intersection_id);
            }
            
            // ================= Incident Cleared Event =================
            EventType::IncidentCleared => {
                println!(
                    "[ANALYSIS] Incident cleared at intersection {}",
                    event.intersection_id
                );
                aggregator.log_event(format!(
                    "Incident cleared at intersection {}",
                    event.intersection_id
                ));
                
                // Reset traffic history for this intersection
                traffic_history.remove(&event.intersection_id);
            }
        }
    }
}
