// //src/components/monitoring_reporting.rs
// use serde::{Serialize, Deserialize};
// use std::fs::{OpenOptions, File};
// use std::io::{Write, BufWriter};
// use chrono::{Local, Utc};
// use std::path::Path;

// #[derive(Serialize, Deserialize, Debug, Clone)]
// pub enum LogEvent {
//     TrafficEvent {
//         intersection_id: u32,
//         vehicle_count: i32,

//         time: String,
//     },
//     LightStateChange {
//         intersection_id: u32,
//         light_id: u8,
//         new_state: String,
//         duration_sec: u32,
//         time: String,
//     },
//     CongestionAlert {
//         intersection_id: u32,
//         severity: u8, // 1-5 scale
//         predicted_delay_sec: u32,
//         time: String,
//     },
// }
// fn current_time() -> String {
//     Local::now().format("%H:%M:%S").to_string()
// }
// pub struct EventLogger {
//     json_file: BufWriter<File>,
//     csv_file: BufWriter<File>,
// }

// impl EventLogger {
//     pub fn new(json_path: &str, csv_path: &str) -> std::io::Result<Self> {
//         // Create directories if they don't exist
//         if let Some(parent) = Path::new(json_path).parent() {
//             std::fs::create_dir_all(parent)?;
//         }
//         if let Some(parent) = Path::new(csv_path).parent() {
//             std::fs::create_dir_all(parent)?;
//         }

//         fn current_time() -> String {
//             Local::now().format("%H:%M:%S").to_string()
//         }
//         // Initialize files with headers if they're new
//         let json_file = OpenOptions::new()
//             .create(true)
//             .append(true)
//             .open(json_path)?;

//         let csv_file = OpenOptions::new()
//             .create(true)
//             .append(true)
//             .open(csv_path)?;

//         let mut logger = Self {
//             json_file: BufWriter::new(json_file),
//             csv_file: BufWriter::new(csv_file),
//         };

//         // Write CSV header if file is empty
//         if logger.csv_file.get_ref().metadata()?.len() == 0 {
//             writeln!(logger.csv_file, "event_type,intersection_id,details,timestamp")?;
//         }

//         Ok(logger)
//     }

//     pub fn log_event(&mut self, event: &LogEvent) -> std::io::Result<()> {
//         // Log to JSON file
//         let json_line = serde_json::to_string(event)?;
//         writeln!(self.json_file, "{}", json_line)?;

//         // Log to CSV file
//         match event {
//             LogEvent::TrafficEvent { intersection_id, vehicle_count, time } => {
//                 writeln!(
//                     self.csv_file,
//                     "TrafficEvent,{},{},{}",
//                     intersection_id, vehicle_count, time
//                 )?;
//             }
//             LogEvent::LightStateChange { intersection_id, light_id, new_state, duration_sec, time } => {
//                 writeln!(
//                     self.csv_file,
//                     "LightChange,{},Light {} -> {} ({}s),{}",
//                     intersection_id, light_id, new_state, duration_sec, time
//                 )?;
//             }
//             LogEvent::CongestionAlert { intersection_id, severity, predicted_delay_sec, time } => {
//                 writeln!(
//                     self.csv_file,
//                     "CongestionAlert,{},Severity {} ({}s delay),{}",
//                     intersection_id, severity, predicted_delay_sec, time
//                 )?;
//             }
//         }

//         // Flush both files
//         self.json_file.flush()?;
//         self.csv_file.flush()?;

//         Ok(())
//     }
// }

// // Example usage
// fn main() -> std::io::Result<()> {
//     let mut logger = EventLogger::new("logs/traffic.json", "logs/traffic.csv")?;

//     // Example traffic event
//     logger.log_event(&LogEvent::TrafficEvent {
//         intersection_id: 1,
//         vehicle_count: 12,
//         time: current_time(),  // Changed from timestamp
//     })?;

//     // Example light state change
//     logger.log_event(&LogEvent::LightStateChange {
//         intersection_id: 1,
//         light_id: 2,
//         new_state: "green".to_string(),
//         duration_sec: 30,
//         time: current_time(),  // Added time field
//     })?;

//     // Example congestion alert
//     logger.log_event(&LogEvent::CongestionAlert {
//         intersection_id: 1,
//         severity: 3,
//         predicted_delay_sec: 45,
//         time: current_time(),  // Added time field
//     })?;

//     Ok(())
// }

// src/components/monitoring_reporting.rs
use chrono::{Local, Utc};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{BufWriter, Write};
use std::path::Path;

#[derive(Serialize, Deserialize, Debug, Clone)]
pub enum LogEvent {
    VehicleEvent {
        event_type: String, // "arrival" or "departure"
        intersection_id: u32,
        vehicle_id: u32,
        current_count: u32,
        timestamp: String,
    },
    LightStateChange {
        intersection_id: u32,
        light_id: u8,
        old_state: String,
        new_state: String,
        duration_sec: u32,
        queue_length: u32,
        timestamp: String,
    },

    CongestionAlert {
        intersection_id: u32,
        vehicle_count: u32,
        timestamp: String,
    },

    IncidentEvent {
        intersection_id: u32,
        description: String,
        expected_delay_sec: u32,
        affected_vehicles: u32,
        timestamp: String,
    },
    SystemSummary {
        total_vehicles: u32,
        congested_intersections: u32,
        average_delay: f32,
        timestamp: String,
    },
}

pub struct EventLogger {
    json_file: BufWriter<File>,
    csv_file: BufWriter<File>,
    pub vehicle_counts: HashMap<u32, u32>, // intersection_id -> count
}

impl EventLogger {
    pub fn new(json_path: &str, csv_path: &str) -> std::io::Result<Self> {
        // Create directories if they don't exist
        if let Some(parent) = Path::new(json_path).parent() {
            std::fs::create_dir_all(parent)?;
        }
        if let Some(parent) = Path::new(csv_path).parent() {
            std::fs::create_dir_all(parent)?;
        }

        // Initialize files
        let json_file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(json_path)?;

        let csv_file = OpenOptions::new()
            .create(true)
            .append(true)
            .open(csv_path)?;

        let mut logger = Self {
            json_file: BufWriter::new(json_file),
            csv_file: BufWriter::new(csv_file),
            vehicle_counts: HashMap::new(),
        };

        // Write CSV header if file is empty
        if logger.csv_file.get_ref().metadata()?.len() == 0 {
            writeln!(
                logger.csv_file,
                "event_type,timestamp,intersection_id,details,vehicle_count,severity,delay"
            )?;
        }

        Ok(logger)
    }

   // Modify the function to take a vector of intersection IDs instead of a count
pub fn log_congestion_alert(
    &mut self,
    intersection_id: u32,
) -> std::io::Result<()> {
    let vehicle_count = *self.vehicle_counts.get(&intersection_id).unwrap_or(&0);
    
    let event = LogEvent::CongestionAlert {
        intersection_id,
        vehicle_count,
        timestamp: current_time(),
    };

    self.log_event(&event)
}


    pub fn log_vehicle_event(
        &mut self,
        event_type: &str,
        intersection_id: u32,
        vehicle_id: u32,
    ) -> std::io::Result<()> {
        // Update vehicle count
        let count = self.vehicle_counts.entry(intersection_id).or_insert(0);
        match event_type {
            "arrival" => *count += 1,
            "departure" => *count = count.saturating_sub(1),
            _ => (),
        }

        let event = LogEvent::VehicleEvent {
            event_type: event_type.to_string(),
            intersection_id,
            vehicle_id,
            current_count: *count,
            timestamp: current_time(),
        };

        self.log_event(&event)
    }

    pub fn log_incident(
        &mut self,
        intersection_id: u32,
        description: String,
        expected_delay_sec: u32,
        affected_vehicles: u32,
    ) -> std::io::Result<()> {
        let event = LogEvent::IncidentEvent {
            intersection_id,
            description,
            expected_delay_sec,
            affected_vehicles,
            timestamp: current_time(),
        };

        self.log_event(&event)
    }

    pub fn log_light_change(
        &mut self,
        intersection_id: u32,
        light_id: u8,
        old_state: String,
        new_state: String,
        duration_sec: u32,
        queue_length: u32,
    ) -> std::io::Result<()> {
        let event = LogEvent::LightStateChange {
            intersection_id,
            light_id,
            old_state,
            new_state,
            duration_sec,
            queue_length,
            timestamp: current_time(),
        };

        self.log_event(&event)
    }

    pub fn log_system_summary(
        &mut self,
        total_vehicles: u32,
        congested_intersections: u32,
        average_delay: f32,
    ) -> std::io::Result<()> {
        let event = LogEvent::SystemSummary {
            total_vehicles,
            congested_intersections,
            average_delay,
            timestamp: current_time(),
        };

        self.log_event(&event)
    }

    fn log_event(&mut self, event: &LogEvent) -> std::io::Result<()> {
        // Log to JSON file
        let json_line = serde_json::to_string(event)?;
        writeln!(self.json_file, "{}", json_line)?;

        // Log to CSV file
        match event {
            LogEvent::VehicleEvent {
                event_type,
                intersection_id,
                vehicle_id,
                current_count,
                timestamp,
            } => {
                writeln!(
                    self.csv_file,
                    "vehicle_{},{},{},Vehicle {},{},,",
                    event_type, timestamp, intersection_id, vehicle_id, current_count
                )?;
            }
            LogEvent::LightStateChange {
                intersection_id,
                light_id,
                old_state,
                new_state,
                duration_sec,
                queue_length,
                timestamp,
            } => {
                writeln!(
                    self.csv_file,
                    "light_change,{},{} Light {},{}->{} ({}s),{},,",
                    timestamp,
                    intersection_id,
                    light_id,
                    old_state,
                    new_state,
                    duration_sec,
                    queue_length
                )?;
            }

            LogEvent::CongestionAlert {
                intersection_id,
                vehicle_count,
                timestamp,
            } => {
                writeln!(
                    self.csv_file,
                    "congestion_alert,{},{},{} vehicles",
                    timestamp, intersection_id, vehicle_count
                )?;
            }
        

            LogEvent::IncidentEvent {
                intersection_id,
                description,
                expected_delay_sec,
                affected_vehicles,
                timestamp,
            } => {
                writeln!(
                    self.csv_file,
                    "incident,{},{} ({} vehicles),{},,{}s,",
                    timestamp, intersection_id, affected_vehicles, description, expected_delay_sec
                )?;
            }
            LogEvent::SystemSummary {
                total_vehicles,
                congested_intersections,
                average_delay,
                timestamp,
            } => {
                writeln!(
                    self.csv_file,
                    "system_summary,{},System,{} vehicles ({} congested),,,{:.1}s",
                    timestamp, total_vehicles, congested_intersections, average_delay
                )?;
            }
        }

        // Flush both files
        self.json_file.flush()?;
        self.csv_file.flush()?;

        Ok(())
    }
}

fn current_time() -> String {
    Local::now().format("%Y-%m-%d %H:%M:%S%.3f").to_string()
}
