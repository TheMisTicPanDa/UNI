use tokio::sync::broadcast;
use std::collections::HashMap;
use chrono::{Utc, DateTime};

#[derive(Debug, Clone, Copy)]
pub enum LightState {
    Red,
    Green,
    Yellow,
}

pub struct TrafficAggregator {
    pub vehicle_counts: HashMap<u32, u32>,
    pub delay_averages: HashMap<u32, f64>,
    pub congestion_counts: HashMap<u32, u32>,
    pub event_logs: Vec<String>,
    pub light_states: HashMap<u32, LightState>,  

    congestion_threshold: u32,
   
}

impl TrafficAggregator {
    pub fn new() -> Self {
        Self {
            vehicle_counts: HashMap::new(),
            delay_averages: HashMap::new(),
            congestion_counts: HashMap::new(),
            event_logs: Vec::new(),
            light_states: HashMap::new(),
      
            congestion_threshold: 10,
            
        }
    }


    pub fn update_light_state(&mut self, intersection_id: u32, state: LightState) {
        self.light_states.insert(intersection_id, state);
        self.log_event(format!(
            "Traffic light at intersection {} changed to {:?}",
            intersection_id, state
        ));
    }
   

    pub fn average_delays(&self) -> f32 {
        if self.delay_averages.is_empty() {
            return 0.0;
        }
        
        let sum: f64 = self.delay_averages.values().sum();
        let count = self.delay_averages.len() as f64;
        (sum / count) as f32
    }

    pub fn log_event(&mut self, message: String) {
        let timestamp: DateTime<Utc> = Utc::now();
        self.event_logs.push(format!("[{}] {}", timestamp, message));
    }

    

    pub fn update_vehicle_count(&mut self, intersection_id: u32, count: i32) {
        let entry = self.vehicle_counts.entry(intersection_id).or_insert(0);
        *entry = (*entry as i32 + count).max(0) as u32;
    }

    pub fn update_delay(&mut self, intersection_id: u32, delay: u64) {
        let alpha = 0.2; // Smoothing factor
        let entry = self.delay_averages.entry(intersection_id).or_insert(0.0);
        
        // If this is the first delay measurement, just set it
        if *entry == 0.0 {
            *entry = delay as f64;
        } else {
            // Otherwise apply exponential smoothing
            *entry = alpha * delay as f64 + (1.0 - alpha) * (*entry);
        }
    }

    pub fn increment_congestion(&mut self, intersection_id: u32) {
        let count = self.congestion_counts.entry(intersection_id).or_insert(0);
        *count += 1;

        

    }

    

    pub fn generate_report(&self) -> String {
        let mut report = String::from("🚦 **Traffic System Overview Report** 🚦\n\n");



        report.push_str("📊 **Vehicle Counts Per Intersection:**\n");
        for (intersection, count) in &self.vehicle_counts {
            report.push_str(&format!("  - Intersection {}: {} vehicles\n", intersection, count));
        }

        report.push_str("\n⏳ **Average Delays Per Intersection:**\n");
        for (intersection, avg_delay) in &self.delay_averages {
            report.push_str(&format!("  - Intersection {}: {:.2} sec avg delay\n", intersection, avg_delay));
        }

       
        report.push_str(&format!("\n⚠️ **Congestion Alerts (Vehicles > {}):**\n", self.congestion_threshold));
        let mut congested_intersections: Vec<_> = self.vehicle_counts.iter()
            .filter(|(_, &count)| count > self.congestion_threshold)
            .collect();
        congested_intersections.sort_by(|a, b| b.1.cmp(a.1));
        
        if congested_intersections.is_empty() {
            report.push_str("  - No intersections currently congested\n");
        } else {
            for (intersection, count) in congested_intersections {
                let severity = if *count > 30 { "🚨 SEVERE" }
                             else if *count > 20 { "🔴 HIGH" }
                             else { "🟠 MEDIUM" };
                report.push_str(&format!("  - {} Intersection {}: {} vehicles\n", severity, intersection, count));
            }
        }
        report.push_str("\n");

        report.push_str("\n📝 **Recent Events:**\n");
        for log in self.event_logs.iter().rev().take(5) {
            report.push_str(&format!("  - {}\n", log));
        }
        report.push_str("\n");

        // report.push_str("🚥 **Current Traffic Light Statuses:**\n");
        // if self.light_states.is_empty() {
        //     report.push_str("  - No light status data available\n");
        // } else {
        //     let mut sorted_lights: Vec<_> = self.light_states.iter().collect();
        //     sorted_lights.sort_by_key(|(id, _)| *id);
            
        //     for (intersection, state) in sorted_lights {
        //         let status_emoji = match state {
        //             LightState::Red => "🔴",
        //             LightState::Green => "🟢",
        //             LightState::Yellow => "🟡",
        //         };
        //         report.push_str(&format!(
        //             "  - Intersection {}: {} {:?}\n",
        //             intersection, status_emoji, state
        //         ));
        //     }
        // }
        report.push_str("\n");

        report
    }
}
