# traffic-simulation-system

## Overview
This project is a **real-time, distributed traffic simulation and management system** designed to improve traffic flow and reduce congestion in a virtual smart city. Built using the **Rust programming language**, the system leverages Rust's safety and concurrency features to deliver an efficient, fault-tolerant, and scalable solution.

The system consists of **four interdependent components** that communicate in real-time to manage traffic across a grid of intersections.

## Components
1. **Traffic Simulation Engine**
   - Simulates traffic events across a grid of intersections.
   - Generates events such as vehicle arrivals, departures, and incidents.
   - Sends real-time updates to the Traffic Flow Analyzer.

2. **Traffic Flow Analyzer**
   - Analyzes traffic patterns and identifies congestion hotspots.
   - Predicts traffic conditions using algorithms.
   - Sends congestion alerts and recommendations to the Traffic Control System.

3. **Traffic Control System**
   - Simulates traffic light operations and adjusts timings dynamically.
   - Ensures fairness and avoids prolonged delays for low-priority roads.
   - Sends feedback about traffic light states to the Monitoring System.

4. **System Monitoring and Reporting**
   - Aggregates data from all components for centralized monitoring.
   - Provides logs, reports, and a CLI interface for administrators.
   - Allows manual interventions (e.g., adjusting light timings).

## Features
- Real-time simulation of traffic flow across a grid.
- Dynamic traffic light control based on congestion levels.
- Predictive analytics for proactive congestion management.
- Fault-tolerant and concurrent system design using Rust.

## Setup Instructions
1. **Install Rust**:
   - Follow the [Rust installation guide](https://www.rust-lang.org/tools/install) to set up Rust on your system.

2. **Clone the Repository**:
   ```bash
   git clone https://github.com/Koreqgt/traffic-simulation-system.git
   cd traffic-simulation-system
   ```

3. **Run the System**:
   - Navigate to the `src/` directory and run:
     ```bash
     cargo run
     ```

4. **Testing**:
   - To run all tests for the system:
     ```bash
     cargo test
     ```
   - To run tests for a specific module, navigate to its directory and execute:
     ```bash
     cargo test
     ```
   - Example for testing the Traffic Simulation Engine:
     ```bash
     cargo test --lib traffic_simulation_engine
     ```

5. **Build the Project**:
   - If you need to build the project manually, run:
     ```bash
     cargo build
     ```