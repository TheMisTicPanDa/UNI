use criterion::{criterion_group, criterion_main, Criterion};
use std::sync::Arc;
use tokio::runtime::Runtime;
use tokio::sync::{broadcast, Mutex};

use traffic_simulation_system::components::system_monitoring_reporting::data_aggregator::TrafficAggregator;
use traffic_simulation_system::components::traffic_simulation_engine::traffic_event::{TrafficEvent, EventType};
use traffic_simulation_system::components::traffic_flow_analyzer::analysis_bench_demo::run_analysis_limited;

fn run_analysis_benchmark(c: &mut Criterion) {
    let rt = Runtime::new().unwrap();

    c.bench_function("run_analysis_limited 100 events", |b| {
        b.to_async(&rt).iter(|| async {
            let (event_tx, event_rx) = broadcast::channel(200); // TrafficEvent
            let (congestion_tx, _) = broadcast::channel::<String>(200); // String
            let (control_tx, _) = broadcast::channel::<String>(200); // String
            let aggregator = Arc::new(Mutex::new(TrafficAggregator::new()));

            // Simulate 100 traffic events
            for i in 0..100 {
                let event = TrafficEvent {
                    intersection_id: i % 4,
                    vehicle_id: Some(i),
                    event_type: EventType::VehicleArrival,
                    delay_seconds: None,
                };
                event_tx.send(event).unwrap();
            }

            run_analysis_limited(event_rx, aggregator, congestion_tx, control_tx, 100).await;
        });
    });
}

// ✅ These must match the benchmark function name above
criterion_group!(analysis_benches, run_analysis_benchmark);
criterion_main!(analysis_benches);
