package javaapplication343;
public interface NewInterface1 {
    default void method2(){
        System.out.println("NewInterface1");
    }
}
