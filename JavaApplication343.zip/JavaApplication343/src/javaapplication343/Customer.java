package javaapplication343;
public class Customer extends Human{
    
    public Customer(){
        //(2) super
        super();
    }
    
    //(4) access modifier
    //private void method1(){}
    public void method1(){}
    
    public static int method11(int a, int b){
        //(8) static
        //int z = super.method11(7,11);
        return 11;
    }
    
    //(5) return type
//    public String method111(){
//        return "123";
//    }

}
