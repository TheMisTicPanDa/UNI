package javaapplication343;
public interface NewInterface {
    int x = 7;
    default void method2(){
        System.out.println("NewInterface");
    }
}
