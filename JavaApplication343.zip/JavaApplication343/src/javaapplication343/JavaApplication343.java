package javaapplication343;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
public class JavaApplication343 implements NewInterface, NewInterface1{
    
    public JavaApplication343(int x){
        
    }
    public JavaApplication343(){
        //(1) this
        this(3);
    }
    
    public static void main(String[] args) {
        //(3) final
        final int x = 11;
        //x = 7;
        new JavaApplication343().method2();
    }    
    
    public void method2(){
        //(6)
        //x = 11;
        //(7)
        NewInterface.super.method2();
    }
    
}
