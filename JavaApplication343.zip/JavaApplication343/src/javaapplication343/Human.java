package javaapplication343;
public class Human {
    int x = 10;
    protected void method1(){}
    public static int method11(int a, int b){
        return 7;
    }
    public int method111(){
        return 7;
    }
}
