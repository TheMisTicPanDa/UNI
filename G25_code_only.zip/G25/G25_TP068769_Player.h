#pragma once
#include <string>
#include "G25_TP072253_Card.h"
#include <iostream>

class Player {
private:
    struct AnsweredNode {
        Card card;
        int points;
        AnsweredNode* next;
        AnsweredNode(const Card& card, int points) : card(card), points(points), next(nullptr) {}
    };

    static int playerCount; // Static member to keep track of the number of players
    std::string name;
    int score;
    AnsweredNode* answeredHead;

public:
    Player();  // Default constructor
    Player(const std::string& name);
    ~Player();

    std::string getName() const;
    void answerQuestion(const Card& card, bool correct, bool fromDiscarded);
    int getScore() const;
    void displayAnsweredQuestions() const;

    static bool isPlayerLimitReached(); // Static member function to check if player limit is reached
};

int Player::playerCount = 0; // Initialize static member

Player::Player() : name("Unnamed"), score(0), answeredHead(nullptr) {
    if (playerCount >= 20) {
        throw std::runtime_error("Player limit reached.");
    }
    ++playerCount;
}

Player::Player(const std::string& playerName) : name(playerName), score(0), answeredHead(nullptr) {
    if (playerCount >= 20) {
        throw std::runtime_error("Player limit reached.");
    }
    ++playerCount;
}

Player::~Player() {
    while (answeredHead) {
        AnsweredNode* temp = answeredHead;
        answeredHead = answeredHead->next;
        delete temp;
    }
    --playerCount; // Decrement player count upon destruction
}

std::string Player::getName() const {
    return name;
}

void Player::answerQuestion(const Card& card, bool correct, bool fromDiscarded) {
    int points = 0;
    if (correct) {
        points = fromDiscarded ? static_cast<int>(card.getScore() * 0.8) : card.getScore();
        score += points;
    }

    AnsweredNode* newNode = new AnsweredNode(card, points);
    newNode->next = answeredHead;
    answeredHead = newNode;
}

int Player::getScore() const {
    return score;
}

void Player::displayAnsweredQuestions() const {
    std::cout << "Answered Questions for " << name << ":\n";
    AnsweredNode* current = answeredHead;
    while (current) {
        std::cout << "Question: " << current->card.getQuestion() << "\n";
        std::cout << "Answer: " << current->card.getAnswer() << "\n";
        std::cout << "Points Earned: " << current->points << "\n\n";
        current = current->next;
    }
}

bool Player::isPlayerLimitReached() {
    return playerCount >= 20;
}
