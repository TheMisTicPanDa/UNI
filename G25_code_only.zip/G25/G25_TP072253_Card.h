#pragma once
#include <string>

class Card {
public:
    // Default constructor
    Card() : question(""), answer(""), score(0) {}

    Card(const std::string& question, const std::string& answer, int score)
        : question(question), answer(answer), score(score) {}

    const std::string& getQuestion() const { return question; }
    const std::string& getAnswer() const { return answer; }
    int getScore() const { return score; }

private:
    std::string question;
    std::string answer;
    int score;
};
