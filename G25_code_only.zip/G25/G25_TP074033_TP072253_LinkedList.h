#pragma once

#include "G25_TP072253_Card.h"
#include <cstdlib>  // For std::rand and std::srand
#include <ctime>    // For std::time>
#include <algorithm>
#include <stdexcept>  // Include for std::out_of_range

class LinkedList {
private:
    struct Node {
        Card card;
        Node* next;
        Node(const Card& card) : card(card), next(nullptr) {}
    };

    Node* head;
    Node* tail;

public:
    LinkedList() : head(nullptr), tail(nullptr) {}
    ~LinkedList();

    void addCard(const Card& card);
    Card drawCard();
    void shuffle();
    bool isEmpty() const;
};

LinkedList::~LinkedList() {
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}

void LinkedList::addCard(const Card& card) {
    Node* newNode = new Node(card);
    if (!tail) {
        head = tail = newNode;
    }
    else {
        tail->next = newNode;
        tail = newNode;
    }
}

Card LinkedList::drawCard() {
    if (isEmpty()) {
        throw std::out_of_range("The deck is empty.");
    }

    Node* temp = head;
    Card card = head->card;
    head = head->next;
    if (!head) {
        tail = nullptr;
    }
    delete temp;
    return card;
}

void LinkedList::shuffle() {
 
    const int MAX_CARDS = 300;  // Arbitrary limit for simplicity
    Card cards[MAX_CARDS];
    int count = 0;

    Node* current = head;
    while (current && count < MAX_CARDS) {
        cards[count++] = current->card;
        current = current->next;
    }

    std::srand(std::time(0));
    std::random_shuffle(cards, cards + count);

    current = head;
    for (int i = 0; i < count; ++i) {
        current->card = cards[i];
        current = current->next;
    }
}

bool LinkedList::isEmpty() const {
    return head == nullptr;
}
