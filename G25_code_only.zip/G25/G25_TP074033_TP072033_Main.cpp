#include <iostream>
#include <fstream>
#include <sstream>
#include "G25_TP072253_Card.h"
#include "G25_TP068769_Player.h"
#include "G25_TP074033_TP072253_LinkedList.h"
#include "G25_TP067863_TP072033_BST.h"

// Function to initialize questions from a file
void initializeQuestionsFromFile(LinkedList& deck, const std::string& filename) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error opening file: " << filename << "\n";
        exit(1);
    }

    std::string line;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string question, answer, scoreStr;
        std::getline(ss, question, ',');
        std::getline(ss, answer, ',');
        std::getline(ss, scoreStr, ',');

        int score = std::stoi(scoreStr);
        deck.addCard(Card(question, answer, score));
    }

    // Shuffle the deck after loading questions
    deck.shuffle();
}

// Function to display the game rules
void displayRules() {
    std::cout << "Group25! Trivial Pursuit! Good luck! Have fun!\n\n";
    std::cout << "Rules:\n";
    std::cout << "1. There are three decks of cards: unanswered questions, answered questions, and discarded cards.\n";
    std::cout << "2. There are 300 questions about data structures and algorithms.\n";
    std::cout << "3. Each player gets three rounds to answer questions.\n";
    std::cout << "4. Players can choose a card from the unanswered questions deck or the discarded deck.\n";
    std::cout << "5. Correct answers from the unanswered deck score full points, while correct answers from the discarded deck score 80%.\n";
    std::cout << "6. Answered cards go to the answered deck, while discarded cards go to the discarded deck.\n";
    std::cout << "7. After three rounds, the top 30 players will be displayed.\n";
    std::cout << "8. Players can view their scores and the questions they answered.\n";
    std::cout << "\n";
}

// Function to get a valid 'Y' or 'N' input from the user
char getYesNoInput(const std::string& prompt) {
    char input;
    while (true) {
        std::cout << prompt;
        std::cin >> input;
        if (input == 'Y' || input == 'y' || input == 'N' || input == 'n') {
            return input;
        }
        else {
            std::cout << "Invalid input. Please enter 'Y' or 'N'.\n";
        }
    }
}

// Function to get a valid 'T' or 'F' input from the user
std::string getTrueFalseInput(const std::string& prompt) {
    std::string input;
    while (true) {
        std::cout << prompt;
        std::cin >> input;
        if (input == "T" || input == "F" ) {
            return input;
        }
        else {
            std::cout << "Invalid input. Please enter 'T' or F'.\n";
        }
    }
}

// Function to get a valid deck choice input from the user
int getDeckChoice(const std::string& prompt, bool discardedDeckEmpty) {
    int choice;
    while (true) {
        std::cout << prompt;
        std::cin >> choice;

        if (std::cin.fail()) {
            // Clear the error state
            std::cin.clear();
            // Ignore the rest of the input until the next newline
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter '1' or '2'.\n";
        }
        else if (choice == 1 || choice == 2) {
            if (choice == 2 && discardedDeckEmpty) {
                std::cout << "The discarded deck is empty. Choosing from the unanswered deck instead.\n";
                return 1;
            }
            return choice;
        }
        else {
            std::cout << "Invalid input. Please enter '1' or '2'.\n";
        }
    }
}

int main() {
    LinkedList unansweredDeck;
    LinkedList answeredDeck;
    LinkedList discardedDeck;

    // Initialize questions from the text file
    initializeQuestionsFromFile(unansweredDeck, "questions.txt");

    displayRules();

    char startGame = getYesNoInput("Do you want to start the game? (Y/N): ");

    if (startGame != 'Y' && startGame != 'y') {
        std::cout << "Exiting the game. Goodbye!\n";
        return 0;
    }

    int numPlayers;
    bool validInput = false;

    do {
        std::cout << "Enter number of players (up to 30): ";
        std::cin >> numPlayers;

        if (numPlayers > 0 && numPlayers <= 30) {
            validInput = true;
        }
        else {
            std::cout << "Invalid input. Please enter a number between 1 and 30." << std::endl;
        }
    } while (!validInput);

    Player* players = new Player[numPlayers];
    for (int i = 0; i < numPlayers; ++i) {
        std::string name;
        std::cout << "Enter name of player " << i + 1 << ": ";
        std::cin >> name;
        players[i] = Player(name);
    }

    for (int round = 0; round < 3; ++round) {
        for (int i = 0; i < numPlayers; ++i) {
            Player& player = players[i];
            std::cout << "Round " << round + 1 << " - " << player.getName() << "'s turn.\n";

            int choice = getDeckChoice("Choose a card: 1. Unanswered Deck 2. Discarded Deck: ", discardedDeck.isEmpty());

            Card card = (choice == 1) ? unansweredDeck.drawCard() : discardedDeck.drawCard();
            std::cout << "Question: " << card.getQuestion() << "\n";

            char answerChoice = getYesNoInput("Do you want to answer this question? (Y/N): ");

            if (answerChoice == 'Y' || answerChoice == 'y') {
                std::string answer = getTrueFalseInput("Your answer (T/F): ");

                bool correct = (answer == card.getAnswer());

                player.answerQuestion(card, correct, choice == 2);

                if (correct) {
                    answeredDeck.addCard(card);
                    int points = choice == 2 ? static_cast<int>(card.getScore() * 0.8) : card.getScore();
                    std::cout << "Correct! You have earned " << points << " points.\n";
                }
                else {
                    discardedDeck.addCard(card);
                    std::cout << "Incorrect.\n";
                }
            }
            else {
                discardedDeck.addCard(card);
                std::cout << "You chose to skip the question.\n";
            }

            if (unansweredDeck.isEmpty()) break;
        }
    }

    BST leaderboard;
    for (int i = 0; i < numPlayers; ++i) {
        leaderboard.insert(players[i]);
    }

    std::cout << "Top 30 Players:\n";
    leaderboard.displayTopPlayers(30);

    std::string playerName;
    std::cout << "Enter player name to search: ";
    std::cin >> playerName;
    leaderboard.searchPlayer(playerName);

    for (int i = 0; i < numPlayers; ++i) {
        players[i].displayAnsweredQuestions();
    }

    delete[] players;

    return 0;
}

