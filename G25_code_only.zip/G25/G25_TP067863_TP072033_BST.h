#pragma once
#include<string>
#include "G25_TP068769_Player.h"
#include <iostream>

class BST {
private:
    struct Node {
        Player player;
        Node* left;
        Node* right;
        Node(const Player& player) : player(player), left(nullptr), right(nullptr) {}
    };

    Node* root;

    void insert(Node*& node, const Player& player);
    void inOrderTraversal(Node* node, int& count) const;
    void search(Node* node, const std::string& playerName) const;
    void deleteTree(Node* node);

public:
    BST() : root(nullptr) {}
    ~BST();

    void insert(const Player& player);
    void displayTopPlayers(int count) const;
    void searchPlayer(const std::string& playerName) const;
};
void BST::insert(Node*& node, const Player& player) {
    if (!node) {
        node = new Node(player);
    }
    else if (player.getScore() > node->player.getScore()) {
        insert(node->right, player);
    }
    else {
        insert(node->left, player);
    }
}

void BST::insert(const Player& player) {
    insert(root, player);
}

void BST::inOrderTraversal(Node* node, int& count) const {
    if (node && count > 0) {
        inOrderTraversal(node->right, count);  // Descending order
        if (count > 0) {
            std::cout << node->player.getName() << ": " << node->player.getScore() << "\n";
            --count;
        }
        inOrderTraversal(node->left, count);
    }
}

void BST::displayTopPlayers(int count) const {
    inOrderTraversal(root, count);
}

void BST::search(Node* node, const std::string& playerName) const {
    if (!node) return;
    if (node->player.getName() == playerName) {
        std::cout << node->player.getName() << ": " << node->player.getScore() << "\n";
    }
    else if (playerName < node->player.getName()) {
        search(node->left, playerName);
    }
    else {
        search(node->right, playerName);
    }
}

void BST::searchPlayer(const std::string& playerName) const {
    search(root, playerName);
}

void BST::deleteTree(Node* node) {
    if (node) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
    }
}

BST::~BST() {
    deleteTree(root);
}