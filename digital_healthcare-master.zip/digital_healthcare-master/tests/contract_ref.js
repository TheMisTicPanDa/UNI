class ContractRef {
    constructor(){
        this.accounts = [];
        this.doctors = [];
        this.patients = [];
        this.healthRecord = null;
        this.contractAddress = null;
    }
}

module.exports = ContractRef;