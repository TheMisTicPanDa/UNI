export const SET_DUMMY = "SET_FAQ";
export const SET_AUTH_DATA = "SET_AUTH_DATA";
export const SET_GLOBAL_DATA = "SET_GLOBAL_DATA";